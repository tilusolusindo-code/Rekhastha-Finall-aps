import { RealtimeSocket } from "@/lib/realtime-socket";
import { useCallback, useEffect, useRef, useState } from "react";
import {
  Shield, LogOut, Wallet, Users, GraduationCap, Zap, RefreshCw,
  Ban, CheckCircle2, Lock, KeyRound, Loader2, AlertTriangle, ClipboardList,
  Scale, HardHat, ExternalLink, Gavel, Building2,
  XCircle, Award, RotateCcw, Trophy,
  Plus, Pencil, Trash2, Save, Settings2, Briefcase, FileText, X,
  ShieldCheck, IdCard, LayoutDashboard, TrendingUp, UserCheck, Banknote,
  LineChart as LineChartIcon, CreditCard, Crown, Download,
} from "lucide-react";
import { downloadCsv } from "@/lib/csv-export";
import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, Legend,
} from "recharts";
import {
  adminLogin, adminLogout, adminMe, adminChangePassword, adminResetPassword,
  fetchLedger, forceRelease, fetchFeeMigrationStatus, runFeeMigration,
  fetchAdminUsers, toggleSuspend, AdminError,
  type AdminUserPagination,
  fetchDisputes, refund, fetchOnsite,
  fetchAcademy, submitAcademy,
  fetchAcademyQuestions, createAcademyQuestion, updateAcademyQuestion,
  deleteAcademyQuestion, updateAcademySettings,
  fetchAdminJobs, deleteAdminJob, refundAdminJob, forcePayoutAdminJob,
  fetchAdminLogs,
  fetchKycQueue, verifyKyc,
  fetchAdminStats,
  fetchRevenueStats,
  type LedgerRow, type AdminUserRow,
  type DisputeRow, type OnsiteData,
  type AcademyQuestion, type AcademyCompletion, type AcademyResult,
  type AdminAcademyQuestion, type QuestionInput,
  type JobManagementRow, type AdminLogRow,
  type KycRow, type AdminStats,
  type RevenueStats,
} from "@/lib/admin-client";
import { EmergencyAlarm } from "@/components/emergency-alarm";
import ManualFinanceAdminTab from "@/components/manual-finance-admin-tab";

const API_BASE = "/api";
const GOLD = "#D4AF37";
const LIVE_REFRESH_INTERVAL_MS = 60_000;
const LIVE_RECONNECT_DELAY_MS = 3_000;
const DASHBOARD_REFRESH_EVENTS = ["gig_broadcast", "attendance", "application"] as const;
const REVENUE_REFRESH_EVENTS = ["instant_order_activated", "gig_broadcast"] as const;

function formatRp(v: number): string {
  return "Rp " + Math.round(v).toLocaleString("id-ID");
}

type Tab = "dashboard" | "revenue" | "escrow" | "manual_finance" | "resolution" | "onsite" | "users" | "kyc" | "academy" | "jobs" | "logs" | "akun";

function useAdminRealtimeRefresh(
  load: () => Promise<void>,
  watchedEvents: readonly string[],
): boolean {
  const [connected, setConnected] = useState(false);

  useEffect(() => {
    let disposed = false;
    let socket: RealtimeSocket | null = null;
    let reconnectTimer: number | null = null;

    const connect = () => {
      if (disposed) return;
      const nextSocket = new RealtimeSocket({ admin: true });
      socket = nextSocket;

      nextSocket.onopen = () => {
        if (!disposed) setConnected(true);
      };
      nextSocket.onmessage = (ev) => {
        try {
          const msg = JSON.parse(ev.data) as { type?: string };
          if (msg.type && watchedEvents.includes(msg.type)) void load();
        } catch {
          // Ignore malformed frames; polling continues as a fallback.
        }
      };
      nextSocket.onerror = () => nextSocket.close();
      nextSocket.onclose = () => {
        if (disposed) return;
        setConnected(false);
        reconnectTimer = window.setTimeout(connect, LIVE_RECONNECT_DELAY_MS);
      };
    };

    connect();
    const pollTimer = window.setInterval(() => void load(), LIVE_REFRESH_INTERVAL_MS);

    return () => {
      disposed = true;
      window.clearInterval(pollTimer);
      if (reconnectTimer !== null) window.clearTimeout(reconnectTimer);
      socket?.close();
    };
  }, [load, watchedEvents]);

  return connected;
}

// ── Login gateway ─────────────────────────────────────────────────
function LoginGate({ onSuccess }: { onSuccess: () => void }) {
  const [mode, setMode] = useState<"login" | "reset">("login");
  const [adminId, setAdminId] = useState("");
  const [token, setToken] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  // Reset form state
  const [resetRecovery, setResetRecovery] = useState("");
  const [resetNew, setResetNew] = useState("");
  const [resetConfirm, setResetConfirm] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (busy) return;
    setBusy(true);
    setError(null);
    try {
      await adminLogin(adminId.trim(), token);
      onSuccess();
    } catch (err) {
      setError(err instanceof AdminError ? err.message : "Terjadi kesalahan.");
    } finally {
      setBusy(false);
    }
  };

  const handleReset = async (e: React.FormEvent) => {
    e.preventDefault();
    if (busy) return;
    if (resetNew !== resetConfirm) {
      setError("Konfirmasi kata sandi tidak cocok.");
      return;
    }
    if (resetNew.length < 8) {
      setError("Kata sandi baru minimal 8 karakter.");
      return;
    }
    setBusy(true);
    setError(null);
    setSuccess(null);
    try {
      const result = await adminResetPassword(resetNew, resetRecovery);
      setSuccess("Kredensial berhasil diperbarui. Masuk dengan ID Admin baru dan kata sandi baru.");
      setMode("login");
      setAdminId(result.adminId);
      setToken("");
    } catch (err) {
      setError(err instanceof AdminError ? err.message : "Terjadi kesalahan.");
    } finally {
      setBusy(false);
    }
  };

  const inputCls = "w-full bg-emerald-950/50 border border-emerald-700/50 rounded-xl px-4 py-3 text-sm text-white placeholder-emerald-300/40 focus:outline-none focus:ring-2 focus:ring-amber-400/50";
  const labelCls = "text-xs font-bold text-emerald-100 flex items-center gap-1.5 mb-1.5";

  return (
    <div
      className="min-h-screen flex items-center justify-center px-4"
      style={{ background: "radial-gradient(circle at 50% 20%, #064e3b 0%, #022c22 60%, #01100c 100%)" }}
    >
      <div className="w-full max-w-md">
        <div className="flex flex-col items-center mb-6">
          <div
            className="w-16 h-16 rounded-2xl flex items-center justify-center mb-3 shadow-lg"
            style={{ background: `linear-gradient(135deg, ${GOLD}, #b8912a)` }}
          >
            <Shield className="w-8 h-8 text-emerald-950" strokeWidth={2.5} />
          </div>
          <h1 className="text-xl font-black text-white tracking-tight">Admin Portal</h1>
          <p className="text-sm mt-0.5" style={{ color: GOLD }}>Tilu Saudara Solusindo · Rekhastha</p>
        </div>

        {mode === "login" ? (
          <form
            onSubmit={handleSubmit}
            className="bg-white/5 backdrop-blur border rounded-2xl p-6 space-y-4 shadow-2xl"
            style={{ borderColor: "rgba(212,175,55,0.3)" }}
          >
            <div>
              <label className={labelCls}>
                <Lock className="w-3.5 h-3.5" /> Identitas Admin
              </label>
              <input
                data-testid="input-admin-id"
                value={adminId}
                onChange={(e) => setAdminId(e.target.value)}
                autoComplete="username"
                placeholder="Masukkan Identitas Admin"
                className={inputCls}
              />
            </div>
            <div>
              <label className={labelCls}>
                <KeyRound className="w-3.5 h-3.5" /> Kata Sandi
              </label>
              <input
                data-testid="input-admin-token"
                type="password"
                value={token}
                onChange={(e) => setToken(e.target.value)}
                autoComplete="current-password"
                placeholder="Masukkan Kata Sandi"
                className={inputCls}
              />
            </div>

            {success && (
              <div className="flex items-start gap-2 rounded-xl bg-emerald-500/15 border border-emerald-500/30 px-3 py-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-300 shrink-0 mt-0.5" />
                <p className="text-xs text-emerald-200 leading-relaxed">{success}</p>
              </div>
            )}

            {error && (
              <div className="flex items-start gap-2 rounded-xl bg-red-500/15 border border-red-500/30 px-3 py-2.5">
                <AlertTriangle className="w-4 h-4 text-red-300 shrink-0 mt-0.5" />
                <p className="text-xs text-red-200 leading-relaxed">{error}</p>
              </div>
            )}

            <button
              data-testid="button-admin-login"
              type="submit"
              disabled={busy || !adminId || !token}
              className="w-full font-black py-3.5 rounded-xl text-sm text-emerald-950 transition-all disabled:opacity-50 active:scale-[0.98] flex items-center justify-center gap-2"
              style={{ background: `linear-gradient(135deg, ${GOLD}, #c9a227)` }}
            >
              {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Shield className="w-4 h-4" />}
              Masuk ke Command Center
            </button>

            <button
              type="button"
              onClick={() => { setMode("reset"); setError(null); setSuccess(null); }}
              className="w-full text-center text-xs text-emerald-300/60 hover:text-emerald-200 transition-colors pt-1"
            >
              Lupa kata sandi? Gunakan token pemulihan
            </button>
          </form>
        ) : (
          <form
            onSubmit={handleReset}
            className="bg-white/5 backdrop-blur border rounded-2xl p-6 space-y-4 shadow-2xl"
            style={{ borderColor: "rgba(212,175,55,0.3)" }}
          >
            <div className="flex items-center gap-2 mb-1">
              <RotateCcw className="w-4 h-4 text-amber-400" />
              <h2 className="text-sm font-black text-white">Pulihkan Akun Admin</h2>
            </div>
            <p className="text-[11px] text-emerald-300/70 leading-relaxed -mt-2">
              Gunakan kunci <strong className="text-emerald-200">ADMIN_TOKEN</strong> dari Secrets Replit dan buat kata sandi baru. ID akun akan diperbarui ke nilai <strong className="text-emerald-200">ADMIN_ID</strong>.
            </p>

            <div>
              <label className={labelCls}><KeyRound className="w-3.5 h-3.5" /> Token Pemulihan</label>
              <input
                type="password"
                value={resetRecovery}
                onChange={(e) => setResetRecovery(e.target.value)}
                autoComplete="off"
                placeholder="Masukkan ADMIN_TOKEN baru dari Secrets"
                className={inputCls}
              />
            </div>
            <div>
              <label className={labelCls}><KeyRound className="w-3.5 h-3.5" /> Kata Sandi Baru</label>
              <input
                type="password"
                value={resetNew}
                onChange={(e) => setResetNew(e.target.value)}
                autoComplete="new-password"
                placeholder="Min. 8 karakter"
                className={inputCls}
              />
            </div>
            <div>
              <label className={labelCls}><KeyRound className="w-3.5 h-3.5" /> Konfirmasi Kata Sandi</label>
              <input
                type="password"
                value={resetConfirm}
                onChange={(e) => setResetConfirm(e.target.value)}
                autoComplete="new-password"
                placeholder="Ulangi kata sandi baru"
                className={inputCls}
              />
            </div>

            {error && (
              <div className="flex items-start gap-2 rounded-xl bg-red-500/15 border border-red-500/30 px-3 py-2.5">
                <AlertTriangle className="w-4 h-4 text-red-300 shrink-0 mt-0.5" />
                <p className="text-xs text-red-200 leading-relaxed">{error}</p>
              </div>
            )}

            <button
              type="submit"
              disabled={busy || !resetRecovery || !resetNew || !resetConfirm}
              className="w-full font-black py-3.5 rounded-xl text-sm text-emerald-950 transition-all disabled:opacity-50 active:scale-[0.98] flex items-center justify-center gap-2"
              style={{ background: `linear-gradient(135deg, ${GOLD}, #c9a227)` }}
            >
              {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <RotateCcw className="w-4 h-4" />}
              Reset Kata Sandi
            </button>

            <button
              type="button"
              onClick={() => { setMode("login"); setError(null); }}
              className="w-full text-center text-xs text-emerald-300/60 hover:text-emerald-200 transition-colors pt-1"
            >
              ← Kembali ke halaman masuk
            </button>
          </form>
        )}

        <p className="text-center text-[11px] text-emerald-300/50 mt-4">
          Akses terbatas untuk operator platform. Aktivitas dicatat.
        </p>
      </div>
    </div>
  );
}

// ── Change Password tab (inside CommandCenter) ────────────────────
function ChangePasswordTab() {
  const [oldPw, setOldPw] = useState("");
  const [newPw, setNewPw] = useState("");
  const [confirmPw, setConfirmPw] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (busy) return;
    if (newPw !== confirmPw) { setError("Konfirmasi kata sandi tidak cocok."); return; }
    if (newPw.length < 8) { setError("Kata sandi baru minimal 8 karakter."); return; }
    setBusy(true);
    setError(null);
    setSuccess(null);
    try {
      await adminChangePassword(oldPw, newPw);
      setSuccess("Kata sandi berhasil diubah.");
      setOldPw(""); setNewPw(""); setConfirmPw("");
    } catch (err) {
      setError(err instanceof AdminError ? err.message : "Terjadi kesalahan.");
    } finally {
      setBusy(false);
    }
  };

  const inputCls = "w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-900 focus:outline-none focus:ring-2 focus:ring-emerald-500/40";
  const labelCls = "block text-xs font-bold text-gray-600 mb-1.5";

  return (
    <div className="max-w-md">
      <div className="bg-white border border-gray-100 rounded-2xl p-6 shadow-sm space-y-4">
        <div className="flex items-center gap-2 mb-2">
          <div className="w-8 h-8 rounded-lg bg-emerald-50 flex items-center justify-center">
            <KeyRound className="w-4 h-4 text-emerald-600" />
          </div>
          <div>
            <p className="font-black text-sm text-gray-900">Ganti Kata Sandi</p>
            <p className="text-[11px] text-gray-400">Kata sandi disimpan terenkripsi di database</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3">
          <div>
            <label className={labelCls}>Kata Sandi Lama</label>
            <input
              type="password"
              value={oldPw}
              onChange={(e) => setOldPw(e.target.value)}
              autoComplete="current-password"
              placeholder="Kata sandi saat ini"
              className={inputCls}
            />
          </div>
          <div>
            <label className={labelCls}>Kata Sandi Baru</label>
            <input
              type="password"
              value={newPw}
              onChange={(e) => setNewPw(e.target.value)}
              autoComplete="new-password"
              placeholder="Min. 8 karakter"
              className={inputCls}
            />
          </div>
          <div>
            <label className={labelCls}>Konfirmasi Kata Sandi Baru</label>
            <input
              type="password"
              value={confirmPw}
              onChange={(e) => setConfirmPw(e.target.value)}
              autoComplete="new-password"
              placeholder="Ulangi kata sandi baru"
              className={inputCls}
            />
          </div>

          {error && (
            <div className="flex items-start gap-2 rounded-xl bg-red-50 border border-red-200 px-3 py-2.5">
              <AlertTriangle className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
              <p className="text-xs text-red-700 leading-relaxed">{error}</p>
            </div>
          )}

          {success && (
            <div className="flex items-start gap-2 rounded-xl bg-emerald-50 border border-emerald-200 px-3 py-2.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <p className="text-xs text-emerald-700 leading-relaxed">{success}</p>
            </div>
          )}

          <button
            type="submit"
            disabled={busy || !oldPw || !newPw || !confirmPw}
            className="w-full font-black py-3 rounded-xl text-sm text-white bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 transition-all active:scale-[0.98] flex items-center justify-center gap-2 mt-2"
          >
            {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <KeyRound className="w-4 h-4" />}
            Simpan Kata Sandi Baru
          </button>
        </form>

        <div className="border-t border-gray-100 pt-4 mt-2">
          <p className="text-[11px] text-gray-400 leading-relaxed">
            <strong className="text-gray-500">Lupa kata sandi?</strong> Gunakan fitur &ldquo;Reset Kata Sandi&rdquo; di halaman masuk dengan token pemulihan dari Secrets Replit (<code className="bg-gray-100 px-1 rounded text-[10px]">ADMIN_TOKEN</code>).
          </p>
        </div>
      </div>
    </div>
  );
}

// ── Status badge ──────────────────────────────────────────────────
function StatusBadge({ row }: { row: LedgerRow }) {
  const map = {
    deposited: { label: "Didepositokan", cls: "bg-amber-100 text-amber-800 border-amber-200" },
    working: { label: "Sedang Bekerja", cls: "bg-blue-100 text-blue-800 border-blue-200" },
    released: { label: "Selesai Cair", cls: "bg-emerald-100 text-emerald-800 border-emerald-200" },
  } as const;
  const s = map[row.status];
  return (
    <span className={`inline-block px-2.5 py-1 rounded-full text-[11px] font-bold border ${s.cls}`}>
      {s.label}
    </span>
  );
}

// ── Tab 0: Live Dashboard ─────────────────────────────────────────
function StatCard({
  icon, label, value, sub, color,
}: {
  icon: React.ReactNode;
  label: string;
  value: string | number;
  sub?: string;
  color: string;
}) {
  return (
    <div className="group min-w-0 rounded-2xl border border-[#dfe7e2] bg-[#fffefa] p-4 shadow-[0_2px_8px_rgba(20,49,39,0.035)] transition-shadow hover:shadow-[0_8px_22px_rgba(20,49,39,0.075)] flex items-start gap-3">
      <div
        className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ring-1 ring-black/[0.035]"
        style={{ background: `${color}18` }}
      >
        <span style={{ color }}>{icon}</span>
      </div>
      <div className="min-w-0">
        <p className="text-[10px] font-bold text-[#6b7b73] uppercase tracking-[0.11em] truncate">{label}</p>
        <p className="mt-1 text-[clamp(1.2rem,2vw,1.55rem)] font-extrabold tracking-tight text-[#163b2d] leading-tight tabular-nums">{value}</p>
        {sub && <p className="text-[11px] text-[#87948d] mt-1">{sub}</p>}
      </div>
    </div>
  );
}

function DashboardTab() {
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [loadError, setLoadError] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const requestInFlight = useRef(false);

  const load = useCallback(async () => {
    if (requestInFlight.current) return;
    requestInFlight.current = true;
    setRefreshing(true);
    try {
      const s = await fetchAdminStats();
      setStats(s);
      setLoadError(false);
      setLastUpdated(new Date());
    } catch {
      setLoadError(true);
    } finally {
      setLoading(false);
      setRefreshing(false);
      requestInFlight.current = false;
    }
  }, []);

  const realtimeConnected = useAdminRealtimeRefresh(load, DASHBOARD_REFRESH_EVENTS);
  useEffect(() => { void load(); }, [load]);

  if (loading) {
    return (
      <div className="space-y-7 animate-pulse" aria-label="Memuat statistik">
        {[0, 1, 2].map((group) => (
          <div key={group}>
            <div className="mb-3 h-3 w-24 rounded bg-[#dce7e0]" />
            <div className={`grid gap-3 ${group === 2 ? "grid-cols-1 md:grid-cols-3" : "grid-cols-2 md:grid-cols-4"}`}>
              {Array.from({ length: group === 2 ? 3 : 4 }).map((_, i) => (
                <div key={i} className="h-[84px] rounded-2xl border border-[#e1e9e3] bg-[#fffefa]" />
              ))}
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (!stats) {
    return (
      <div className="rounded-2xl border border-[#ead9c6] bg-[#fffaf2] px-5 py-8 text-center">
        <AlertTriangle className="mx-auto mb-2 h-5 w-5 text-[#a66c28]" />
        <p className="text-sm font-semibold text-[#5d4c38]">Gagal memuat statistik.</p>
        <button disabled={refreshing} onClick={() => void load()} className="mt-3 rounded-lg border border-[#d9c4a9] px-3 py-2 text-xs font-bold text-[#705633] hover:bg-[#f8eedf] disabled:cursor-wait disabled:opacity-60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#997441]">
          {refreshing ? "Memuat ulang…" : "Coba lagi"}
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-7">
      {/* Header bar */}
      <div className="flex flex-wrap items-end justify-between gap-3 border-b border-[#dfe7e2] pb-4">
        <div>
          <div className="mb-1 flex items-center gap-2">
            <span className="relative flex h-2.5 w-2.5"><span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[#479b75] opacity-30" /><span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-[#32845d]" /></span>
            <span className="text-[10px] font-bold uppercase tracking-[0.15em] text-[#518365]">Live platform</span>
          </div>
          <h3 className="text-lg font-extrabold tracking-tight text-[#183c2e]">Statistik Platform Live</h3>
          <p className="mt-1 text-xs text-[#87948d]">
            {lastUpdated
              ? `Diperbarui ${lastUpdated.toLocaleTimeString("id-ID")}`
              : "Memuat…"}
          </p>
        </div>
        <button
          disabled={refreshing}
          onClick={() => void load()}
          className="flex items-center gap-1.5 rounded-lg border border-[#cddfd3] bg-[#eef6f0] px-3.5 py-2 text-xs font-bold text-[#245f43] transition-colors hover:bg-[#e1eee5] disabled:cursor-wait disabled:opacity-60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#4a8763] focus-visible:ring-offset-2"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? "animate-spin" : ""}`} /> Refresh
        </button>
      </div>

      {loadError && (
        <div role="alert" className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[#ead9c6] bg-[#fffaf2] px-4 py-3 text-xs text-[#705633]">
          <span>Pembaruan gagal. Data terakhir tetap ditampilkan.</span>
          <button disabled={refreshing} onClick={() => void load()} className="font-bold underline underline-offset-2 disabled:opacity-60">
            {refreshing ? "Mencoba…" : "Coba lagi"}
          </button>
        </div>
      )}

      {/* Users section */}
      <div>
        <p className="mb-3 text-[10px] font-extrabold text-[#718078] uppercase tracking-[0.16em]">Pengguna</p>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <StatCard
            icon={<Users className="w-5 h-5" />}
            label="Total Pengguna"
            value={stats.totalUsers.toLocaleString("id-ID")}
            sub={`+${stats.newUsersToday} hari ini`}
            color="#10b981"
          />
          <StatCard
            icon={<UserCheck className="w-5 h-5" />}
            label="Pekerja"
            value={stats.workers.toLocaleString("id-ID")}
            color="#3b82f6"
          />
          <StatCard
            icon={<Building2 className="w-5 h-5" />}
            label="Perusahaan"
            value={stats.employers.toLocaleString("id-ID")}
            color="#8b5cf6"
          />
          <StatCard
            icon={<TrendingUp className="w-5 h-5" />}
            label="Daftar Hari Ini"
            value={stats.newUsersToday.toLocaleString("id-ID")}
            color={GOLD}
          />
        </div>
      </div>

      {/* Gigs section */}
      <div>
        <p className="mb-3 text-[10px] font-extrabold text-[#718078] uppercase tracking-[0.16em]">Gig</p>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <StatCard
            icon={<Briefcase className="w-5 h-5" />}
            label="Total Gig"
            value={stats.totalGigs.toLocaleString("id-ID")}
            color="#6b7280"
          />
          <StatCard
            icon={<Zap className="w-5 h-5" />}
            label="Gig Aktif"
            value={stats.activeGigs.toLocaleString("id-ID")}
            sub="Escrow terkunci"
            color="#f97316"
          />
          <StatCard
            icon={<CheckCircle2 className="w-5 h-5" />}
            label="Selesai"
            value={stats.releasedGigs.toLocaleString("id-ID")}
            color="#10b981"
          />
          <StatCard
            icon={<AlertTriangle className="w-5 h-5" />}
            label="Disengketakan"
            value={stats.disputedGigs.toLocaleString("id-ID")}
            color="#ef4444"
          />
        </div>
      </div>

      {/* Escrow section */}
      <div>
        <p className="mb-3 text-[10px] font-extrabold text-[#718078] uppercase tracking-[0.16em]">Escrow</p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div
            className="rounded-2xl border border-[#ead5b4] p-5 text-[#67471d] shadow-[0_3px_12px_rgba(80,58,24,0.045)]"
            style={{ background: "linear-gradient(135deg, #fbf1df, #f7e8cb)" }}
          >
            <div className="flex items-center gap-2 mb-1">
              <Banknote className="w-4 h-4 text-[#a46a22]" />
              <span className="text-[10px] font-extrabold uppercase tracking-[0.12em] text-[#8d652d]">Dana Ditahan</span>
            </div>
            <p className="text-[clamp(1.3rem,2vw,1.7rem)] font-extrabold leading-tight tracking-tight tabular-nums">{formatRp(stats.escrowHeld)}</p>
            <p className="text-[11px] text-[#967951] mt-1">{stats.activeGigs} gig aktif</p>
          </div>
          <div
            className="rounded-2xl border border-[#c9e2d2] p-5 text-[#1f5738] shadow-[0_3px_12px_rgba(35,78,50,0.045)]"
            style={{ background: "linear-gradient(135deg, #e7f3e9, #dcefe1)" }}
          >
            <div className="flex items-center gap-2 mb-1">
              <CheckCircle2 className="w-4 h-4 text-[#398058]" />
              <span className="text-[10px] font-extrabold uppercase tracking-[0.12em] text-[#4f805e]">Dana Cair</span>
            </div>
            <p className="text-[clamp(1.3rem,2vw,1.7rem)] font-extrabold leading-tight tracking-tight tabular-nums">{formatRp(stats.escrowReleased)}</p>
            <p className="text-[11px] text-[#63816c] mt-1">{stats.releasedGigs} gig selesai</p>
          </div>
          <div
            className="rounded-2xl border border-[#edceca] p-5 text-[#773d38] shadow-[0_3px_12px_rgba(100,44,38,0.045)]"
            style={{ background: "linear-gradient(135deg, #f8e9e5, #f4dfdc)" }}
          >
            <div className="flex items-center gap-2 mb-1">
              <Scale className="w-4 h-4 text-[#a2574f]" />
              <span className="text-[10px] font-extrabold uppercase tracking-[0.12em] text-[#9a5e56]">Dana Sengketa</span>
            </div>
            <p className="text-[clamp(1.3rem,2vw,1.7rem)] font-extrabold leading-tight tracking-tight tabular-nums">{formatRp(stats.escrowDisputed)}</p>
            <p className="text-[11px] text-[#9a6c66] mt-1">{stats.disputedGigs} gig sengketa</p>
          </div>
        </div>
      </div>

      {/* Live indicator */}
      <div className="flex items-center justify-center gap-2 border-t border-[#e2e9e4] pt-4 text-[11px] text-[#77867e]">
        <span className={`inline-block h-2 w-2 rounded-full ${realtimeConnected ? "bg-[#49a477]" : "bg-[#c89b55]"}`} />
        {realtimeConnected
          ? "Realtime tersambung · sinkron otomatis tiap menit"
          : "Realtime menghubungkan ulang · sinkron otomatis tiap menit"}
      </div>
    </div>
  );
}

// ── Tab: Revenue analytics (flat-rate Instan Kilat + langganan) ──────
const CATEGORY_LABEL: Record<string, string> = {
  umum: "Umum",
  terampil: "Terampil",
  profesional: "Profesional",
  lainnya: "Lainnya",
};
const CATEGORY_COLOR: Record<string, string> = {
  umum: "#3b82f6",
  terampil: "#f97316",
  profesional: "#8b5cf6",
  lainnya: "#6b7280",
};

function RevenueTab() {
  const [stats, setStats] = useState<RevenueStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [loadError, setLoadError] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const requestInFlight = useRef(false);

  const load = useCallback(async () => {
    if (requestInFlight.current) return;
    requestInFlight.current = true;
    setRefreshing(true);
    try {
      const s = await fetchRevenueStats();
      setStats(s);
      setLoadError(false);
      setLastUpdated(new Date());
    } catch {
      setLoadError(true);
    } finally {
      setLoading(false);
      setRefreshing(false);
      requestInFlight.current = false;
    }
  }, []);

  const realtimeConnected = useAdminRealtimeRefresh(load, REVENUE_REFRESH_EVENTS);
  useEffect(() => { void load(); }, [load]);

  if (loading) {
    return (
        <div className="space-y-5 animate-pulse" aria-label="Memuat analitik pendapatan">
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">{[0, 1, 2, 3].map((i) => <div key={i} className="h-28 rounded-2xl border border-[#e1e9e3] bg-[#fffefa]" />)}</div>
          <div className="h-[320px] rounded-2xl border border-[#e1e9e3] bg-[#fffefa]" />
          <div className="grid gap-4 md:grid-cols-2"><div className="h-64 rounded-2xl border border-[#e1e9e3] bg-[#fffefa]" /><div className="h-64 rounded-2xl border border-[#e1e9e3] bg-[#fffefa]" /></div>
        </div>
    );
  }

  if (!stats) {
    return (
      <div className="rounded-2xl border border-[#ead9c6] bg-[#fffaf2] px-5 py-8 text-center">
        <AlertTriangle className="mx-auto mb-2 h-5 w-5 text-[#a66c28]" />
        <p className="text-sm font-semibold text-[#5d4c38]">Gagal memuat data pendapatan.</p>
        <button disabled={refreshing} onClick={() => void load()} className="mt-3 rounded-lg border border-[#d9c4a9] px-3 py-2 text-xs font-bold text-[#705633] hover:bg-[#f8eedf] disabled:cursor-wait disabled:opacity-60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#997441]">
          {refreshing ? "Memuat ulang…" : "Coba lagi"}
        </button>
      </div>
    );
  }

  const chartData = stats.daily.map((d) => ({
    ...d,
    label: new Date(d.date).toLocaleDateString("id-ID", { day: "2-digit", month: "short" }),
  }));

  const categoryEntries = Object.entries(stats.byCategory).filter(([, v]) => v.count > 0);

  const handleExportCsv = () => {
    const rows: (string | number)[][] = [
      ["Ringkasan Pendapatan Rekhastha"],
      ["Total Pendapatan (Rp)", stats.totalRevenue],
      ["Pendapatan Hari Ini (Rp)", stats.todayRevenue],
      ["Pendapatan Biaya Posting (Rp)", stats.postingRevenue],
      ["Lowongan Terbayar", stats.totalPaidPostings],
      ["Pendapatan Langganan (Rp)", stats.subscriptionRevenue],
      ["Langganan Aktif", stats.activeSubscriptions],
      [],
      ["Kategori", "Jumlah Pesanan", "Total (Rp)"],
      ...categoryEntries.map(([cat, v]) => [cat, v.count, v.amount]),
      [],
      ["Tanggal", "Posting (Rp)", "Langganan (Rp)", "Total (Rp)"],
      ...stats.daily.map((d) => [
        new Date(d.date).toLocaleDateString("id-ID"),
        d.postings,
        d.subscription,
        d.total,
      ]),
    ];
    downloadCsv(`pendapatan-rekhastha-${new Date().toISOString().slice(0, 10)}.csv`, rows);
  };

  return (
    <div className="space-y-7">
      <div className="flex flex-wrap items-end justify-between gap-3 border-b border-[#dfe7e2] pb-4">
        <div>
          <div className="mb-1 flex items-center gap-2">
            <span className="relative flex h-2.5 w-2.5"><span className="absolute inline-flex h-full w-full rounded-full bg-[#479b75] opacity-30" /><span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-[#32845d]" /></span>
            <span className="text-[10px] font-bold uppercase tracking-[0.15em] text-[#518365]">Pendapatan</span>
          </div>
          <h3 className="text-lg font-extrabold tracking-tight text-[#183c2e]">Analitik Pendapatan</h3>
          <p className="mt-1 text-xs text-[#87948d]">
            {lastUpdated ? `Diperbarui ${lastUpdated.toLocaleTimeString("id-ID")}` : "Memuat…"}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            data-testid="button-export-revenue-csv"
            onClick={handleExportCsv}
            className="flex items-center gap-1.5 rounded-lg border border-[#d5dedb] bg-[#f3f6f4] px-3.5 py-2 text-xs font-bold text-[#40564b] transition-colors hover:bg-[#e8efeb] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#779786] focus-visible:ring-offset-2"
          >
            <Download className="w-3.5 h-3.5" /> Unduh CSV
          </button>
          <button
            disabled={refreshing}
            onClick={() => void load()}
            className="flex items-center gap-1.5 rounded-lg border border-[#cddfd3] bg-[#eef6f0] px-3.5 py-2 text-xs font-bold text-[#245f43] transition-colors hover:bg-[#e1eee5] disabled:cursor-wait disabled:opacity-60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#4a8763] focus-visible:ring-offset-2"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? "animate-spin" : ""}`} /> Refresh
          </button>
        </div>
      </div>

      {loadError && (
        <div role="alert" className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[#ead9c6] bg-[#fffaf2] px-4 py-3 text-xs text-[#705633]">
          <span>Pembaruan gagal. Data terakhir tetap ditampilkan.</span>
          <button disabled={refreshing} onClick={() => void load()} className="font-bold underline underline-offset-2 disabled:opacity-60">
            {refreshing ? "Mencoba…" : "Coba lagi"}
          </button>
        </div>
      )}

      {/* Summary cards */}
      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        <div
          className="col-span-2 rounded-2xl border border-[#c9e2d2] p-5 text-[#1f5738] shadow-[0_3px_12px_rgba(35,78,50,0.045)] sm:col-span-1"
          style={{ background: "linear-gradient(135deg, #e5f2e7, #d7ebdc)" }}
        >
          <div className="flex items-center gap-2 mb-1">
            <Wallet className="w-4 h-4 text-[#398058]" />
            <span className="text-[10px] font-extrabold uppercase tracking-[0.12em] text-[#4f805e]">Total Pendapatan</span>
          </div>
          <p className="mt-1 text-[clamp(1.15rem,2vw,1.55rem)] font-extrabold leading-tight tracking-tight tabular-nums">{formatRp(stats.totalRevenue)}</p>
          <p className="text-[11px] text-[#63816c] mt-1">Sepanjang waktu</p>
        </div>
        <StatCard
          icon={<TrendingUp className="w-5 h-5" />}
          label="Pendapatan Hari Ini"
          value={formatRp(stats.todayRevenue)}
          color={GOLD}
        />
        <StatCard
          icon={<Zap className="w-5 h-5" />}
          label="Biaya Posting"
          value={formatRp(stats.postingRevenue)}
          sub={`${stats.totalPaidPostings} lowongan terbayar`}
          color="#f97316"
        />
        <StatCard
          icon={<Crown className="w-5 h-5" />}
          label="Langganan Bulanan"
          value={formatRp(stats.subscriptionRevenue)}
          sub={`${stats.activeSubscriptions} perusahaan aktif`}
          color="#8b5cf6"
        />
      </div>

      {/* Trend chart */}
      <div className="rounded-2xl border border-[#dfe7e2] bg-[#fffefa] p-4 shadow-[0_2px_10px_rgba(20,49,39,0.035)] sm:p-5">
        <div className="flex items-center gap-2 mb-4">
          <LineChartIcon className="w-4 h-4 text-[#367654]" />
          <h4 className="font-extrabold tracking-tight text-[#183c2e] text-sm">Tren Pendapatan 14 Hari Terakhir</h4>
        </div>
        <ResponsiveContainer width="100%" height={280}>
          <LineChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e6ece7" />
            <XAxis dataKey="label" tick={{ fontSize: 11, fill: "#77867e" }} axisLine={{ stroke: "#dfe7e2" }} tickLine={false} />
            <YAxis
              tick={{ fontSize: 11, fill: "#77867e" }}
              tickFormatter={(v: number) => `${Math.round(v / 1000)}k`}
              width={45}
              axisLine={false}
              tickLine={false}
            />
            <Tooltip
              formatter={(value: number) => formatRp(value)}
              labelFormatter={(label: string) => `Tanggal: ${label}`}
            />
            <Legend wrapperStyle={{ fontSize: 11, color: "#64766c", paddingTop: 8 }} />
            <Line type="monotone" dataKey="postings" name="Biaya Posting" stroke="#f97316" strokeWidth={2} dot={false} />
            <Line type="monotone" dataKey="subscription" name="Langganan" stroke="#8b5cf6" strokeWidth={2} dot={false} />
            <Line type="monotone" dataKey="total" name="Total" stroke="#10b981" strokeWidth={2.5} dot={false} />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Breakdown by category */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="rounded-2xl border border-[#dfe7e2] bg-[#fffefa] p-4 shadow-[0_2px_10px_rgba(20,49,39,0.035)] sm:p-5">
          <div className="flex items-center gap-2 mb-4">
            <CreditCard className="w-4 h-4 text-[#367654]" />
            <h4 className="font-extrabold tracking-tight text-[#183c2e] text-sm">Pendapatan per Kategori (Instan Kilat)</h4>
          </div>
          {categoryEntries.length === 0 ? (
            <p className="text-sm text-gray-400 py-8 text-center">Belum ada pesanan terbayar.</p>
          ) : (
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={categoryEntries.map(([cat, v]) => ({
                name: CATEGORY_LABEL[cat] ?? cat,
                amount: v.amount,
                count: v.count,
                fill: CATEGORY_COLOR[cat] ?? "#6b7280",
              }))}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e6ece7" />
                <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} tickFormatter={(v: number) => `${Math.round(v / 1000)}k`} width={45} />
                <Tooltip formatter={(value: number) => formatRp(value)} />
                <Bar dataKey="amount" name="Pendapatan" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>

        <div className="rounded-2xl border border-[#dfe7e2] bg-[#fffefa] p-4 shadow-[0_2px_10px_rgba(20,49,39,0.035)] sm:p-5">
          <div className="flex items-center gap-2 mb-4">
            <ClipboardList className="w-4 h-4 text-[#367654]" />
            <h4 className="font-extrabold tracking-tight text-[#183c2e] text-sm">Rincian Kategori</h4>
          </div>
          <div className="space-y-2.5">
            {(["umum", "terampil", "profesional"] as const).map((cat) => {
              const v = stats.byCategory[cat] ?? { count: 0, amount: 0 };
              return (
                <div key={cat} className="flex items-center justify-between border-b border-gray-50 pb-2.5 last:border-0">
                  <div className="flex items-center gap-2">
                    <span
                      className="w-2.5 h-2.5 rounded-full shrink-0"
                      style={{ background: CATEGORY_COLOR[cat] }}
                    />
                    <span className="text-sm font-bold text-gray-700">{CATEGORY_LABEL[cat]}</span>
                    <span className="text-[11px] text-gray-400">({v.count}x)</span>
                  </div>
                  <span className="text-sm font-black text-gray-900">{formatRp(v.amount)}</span>
                </div>
              );
            })}
            <div className="flex items-center justify-between pt-1">
              <span className="text-sm font-bold text-gray-700">Langganan Bulanan (Rp149.000)</span>
              <span className="text-sm font-black text-gray-900">{formatRp(stats.subscriptionRevenue)}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="flex items-center justify-center gap-2 border-t border-[#e2e9e4] pt-4 text-[11px] text-[#77867e]">
        <span className={`inline-block h-2 w-2 rounded-full ${realtimeConnected ? "bg-[#49a477]" : "bg-[#c89b55]"}`} />
        {realtimeConnected
          ? "Realtime tersambung · sinkron otomatis tiap menit"
          : "Realtime menghubungkan ulang · sinkron otomatis tiap menit"}
      </div>
    </div>
  );
}

// ── Tab 1: Escrow ledger ──────────────────────────────────────────
function EscrowTab({ trainingPassed, requireAcademy }: { trainingPassed: boolean; requireAcademy: boolean }) {
  const [rows, setRows] = useState<LedgerRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [releasing, setReleasing] = useState<number | null>(null);
  const [migrationPending, setMigrationPending] = useState(0);
  const [migrationNeedsReview, setMigrationNeedsReview] = useState(0);
  const [migrationComplete, setMigrationComplete] = useState(false);
  const [migrating, setMigrating] = useState(false);
  const [migrationMessage, setMigrationMessage] = useState("");

  const load = useCallback(async () => {
    try {
      const [ledger, migration] = await Promise.all([fetchLedger(), fetchFeeMigrationStatus()]);
      setRows(ledger);
      setMigrationPending(migration.pending);
      setMigrationNeedsReview(migration.needsReview);
      setMigrationComplete(migration.complete);
    } catch {
      /* keep last known rows */
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
    // Live: refetch whenever any device posts a gig or scans attendance.
    const ws = new RealtimeSocket({ admin: true });
    ws.onmessage = (ev) => {
      try {
        const msg = JSON.parse(ev.data) as { type?: string };
        if (msg.type === "gig_broadcast" || msg.type === "attendance") void load();
      } catch {
        /* ignore malformed frames */
      }
    };
    return () => ws.close();
  }, [load]);

  const handleRelease = async (jobId: number) => {
    setReleasing(jobId);
    try {
      await forceRelease(jobId);
      await load();
    } catch {
      /* the ledger reload will reflect the true state */
    } finally {
      setReleasing(null);
    }
  };

  const handleMigration = async () => {
    if (migrationPending === 0 || migrationComplete || migrating) return;
    const confirmed = window.confirm(
      `Hitung ulang snapshot biaya admin dan total upah untuk ${migrationPending} lowongan? Migrasi hanya boleh dijalankan sekali; transfer dan saldo dompet historis tidak diubah.`,
    );
    if (!confirmed) return;
    setMigrating(true);
    setMigrationMessage("");
    try {
      const result = await runFeeMigration();
      setMigrationMessage(
        `${result.migrated} lowongan diperbarui; ${result.remaining} perlu ditinjau manual. Transfer dan saldo dompet historis tetap.`,
      );
      setMigrationComplete(result.complete);
      await load();
    } catch (error) {
      setMigrationMessage(error instanceof Error ? error.message : "Migrasi gagal dijalankan.");
    } finally {
      setMigrating(false);
    }
  };

  const totalHeld = rows
    .filter((r) => r.paymentStatus === "confirmed" && r.status !== "released")
    .reduce((s, r) => s + (r.totalSetoran ?? 0), 0);
  const totalAdminFee = rows.reduce((s, r) => s + (r.komisiPlatform ?? 0), 0);

  return (
    <div className="space-y-5">
      {!trainingPassed && (
        <div
          data-testid="training-required-banner"
          className="flex items-start gap-3 rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3.5 shadow-sm"
        >
          <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
          <div>
            <p className="font-black text-amber-900 text-sm">Pelatihan belum selesai</p>
            <p className="text-xs text-amber-700 mt-0.5">
              Tombol <strong>Paksa Pencairan</strong> dinonaktifkan hingga Anda lulus Asesmen Onboarding Operator.
              Kunjungi tab <strong>Kurasi Akademi</strong> untuk menyelesaikannya.
            </p>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <SummaryCard label="Total Dana Ditahan (Escrow)" value={formatRp(totalHeld)} tone="amber" />
        <SummaryCard label="Total Biaya Admin" value={formatRp(totalAdminFee)} tone="gold" />
        <SummaryCard label="Jumlah Transaksi" value={String(rows.length)} tone="emerald" />
      </div>

      <section className="flex flex-col gap-3 rounded-2xl border border-amber-200 bg-amber-50 p-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <p className="font-bold text-amber-950">Migrasi biaya lowongan lama</p>
          <p className="mt-1 text-xs text-amber-800">
            {migrationComplete
              ? `Migrasi sudah dijalankan satu kali. ${migrationNeedsReview} lowongan masih memerlukan peninjauan manual.`
              : `${migrationPending} lowongan memiliki snapshot yang hilang atau berbeda dari tarif tetap. ${migrationNeedsReview} memiliki nilai upah yang perlu ditinjau.`}
            {" "}Transfer terkonfirmasi dan saldo dompet tidak diubah.
          </p>
          {migrationMessage && <p role="status" className="mt-2 text-xs font-semibold text-amber-950">{migrationMessage}</p>}
        </div>
        <button
          type="button"
          onClick={() => void handleMigration()}
          disabled={migrationPending === 0 || migrationComplete || migrating}
          className="inline-flex shrink-0 items-center justify-center gap-2 rounded-xl bg-amber-700 px-4 py-2.5 text-xs font-bold text-white disabled:opacity-50"
        >
          {migrating ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
          {migrating ? "Memproses…" : migrationComplete ? "Migrasi sudah dijalankan" : migrationPending === 0 ? "Snapshot sudah sesuai" : "Jalankan migrasi sekali"}
        </button>
      </section>

      <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden shadow-sm">
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-gray-100">
          <h3 className="font-black text-gray-900 flex items-center gap-2">
            <Wallet className="w-4 h-4 text-emerald-700" /> Pengawasan Escrow &amp; Transaksi
          </h3>
          <button
            onClick={() => void load()}
            className="flex items-center gap-1.5 text-xs font-bold text-emerald-700 hover:text-emerald-900"
          >
            <RefreshCw className="w-3.5 h-3.5" /> Segarkan
          </button>
        </div>

        {loading ? (
          <div className="py-16 flex justify-center"><Loader2 className="w-6 h-6 animate-spin text-emerald-600" /></div>
        ) : rows.length === 0 ? (
          <div className="py-16 text-center text-sm text-gray-400">Belum ada transaksi escrow.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-gray-50 text-left text-[11px] uppercase tracking-wide text-gray-500">
                  <th className="px-4 py-2.5 font-bold">Job ID</th>
                  <th className="px-4 py-2.5 font-bold">Perusahaan</th>
                  <th className="px-4 py-2.5 font-bold">Pekerja</th>
                  <th className="px-4 py-2.5 font-bold text-right">Total Upah</th>
                  <th className="px-4 py-2.5 font-bold text-right">Biaya Admin</th>
                  <th className="px-4 py-2.5 font-bold text-right">Total Setoran</th>
                  <th className="px-4 py-2.5 font-bold">Status</th>
                  <th className="px-4 py-2.5 font-bold text-right">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {rows.map((r) => (
                  <tr key={r.jobId} data-testid={`ledger-row-${r.jobId}`} className="hover:bg-gray-50/60">
                    <td className="px-4 py-3 font-mono text-[11px] text-gray-500">{r.jobId}</td>
                    <td className="px-4 py-3">
                      <p className="font-semibold text-gray-900">{r.employerName}</p>
                      <p className="text-[11px] text-gray-400">{r.posisi}</p>
                    </td>
                    <td className="px-4 py-3 text-gray-700">{r.workerName}</td>
                    <td className="px-4 py-3 text-right font-bold text-emerald-700">
                      {r.totalUpah === null ? "Belum dimigrasi" : formatRp(r.totalUpah)}
                    </td>
                    <td className="px-4 py-3 text-right font-semibold text-gray-600">
                      {r.komisiPlatform === null ? "Belum dimigrasi" : formatRp(r.komisiPlatform)}
                    </td>
                    <td className="px-4 py-3 text-right font-bold text-gray-900">
                      {r.totalSetoran === null ? "Snapshot belum lengkap" : formatRp(r.totalSetoran)}
                    </td>
                    <td className="px-4 py-3"><StatusBadge row={r} /></td>
                    <td className="px-4 py-3 text-right">
                      {r.status !== "released" && r.payoutEligible ? (
                        requireAcademy && !trainingPassed ? (
                          /* Hard gate: server enforces REQUIRE_ACADEMY=true */
                          <span
                            data-testid={`button-force-release-${r.jobId}`}
                            title="Selesaikan Asesmen Akademi untuk mengaktifkan fitur ini"
                            className="inline-flex items-center gap-1.5 rounded-lg bg-gray-200 text-gray-400 text-[11px] font-bold px-2.5 py-1.5 cursor-not-allowed select-none"
                          >
                            <Lock className="w-3 h-3" /> Paksa Pencairan
                          </span>
                        ) : (
                          /* Soft gate or trained: button active */
                          <button
                            data-testid={`button-force-release-${r.jobId}`}
                            onClick={() => void handleRelease(r.jobId)}
                            disabled={releasing === r.jobId}
                            className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-700 text-white text-[11px] font-bold px-2.5 py-1.5 hover:bg-emerald-600 disabled:opacity-50"
                          >
                            {releasing === r.jobId ? <Loader2 className="w-3 h-3 animate-spin" /> : <Zap className="w-3 h-3" />}
                            Paksa Pencairan
                          </button>
                        )
                      ) : r.status === "released" ? (
                        <span className="inline-flex items-center gap-1 text-[11px] text-emerald-600 font-semibold">
                          <CheckCircle2 className="w-3.5 h-3.5" /> Selesai
                        </span>
                      ) : (
                        <span className="text-[11px] text-gray-400">Menunggu pembayaran atau pekerja</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

// ── Tab 2: User management ────────────────────────────────────────
function UsersTab() {
  const [rows, setRows] = useState<AdminUserRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState<string | null>(null);

  // ── Pagination & filter state ─────────────────────────────────
  const [page, setPage] = useState(1);
  const [pagination, setPagination] = useState<AdminUserPagination | null>(null);
  const [search, setSearch] = useState("");
  const [roleFilter, setRoleFilter] = useState("all");
  const [onlySuspended, setOnlySuspended] = useState(false);
  const [searchInput, setSearchInput] = useState("");

  const LIMIT = 50;

  const load = useCallback(async (p: number, q: string, role: string, susp: boolean) => {
    setLoading(true);
    try {
      const res = await fetchAdminUsers({
        page: p,
        limit: LIMIT,
        q: q || undefined,
        role: role === "all" ? undefined : role,
        suspended: susp || undefined,
      });
      setRows(res.users);
      setPagination(res.pagination);
    } catch {
      /* keep last known rows */
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void load(page, search, roleFilter, onlySuspended); }, [load, page, search, roleFilter, onlySuspended]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setPage(1);
    setSearch(searchInput);
  };

  const handleToggle = async (u: AdminUserRow) => {
    setBusyId(u.id);
    try {
      const res = await toggleSuspend(u.id, !u.suspended);
      setRows((prev) => prev.map((r) => (r.id === u.id ? { ...r, suspended: res.suspended } : r)));
    } catch {
      /* ignore */
    } finally {
      setBusyId(null);
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden shadow-sm">
      {/* Header */}
      <div className="px-5 py-3.5 border-b border-gray-100 flex flex-col sm:flex-row sm:items-center gap-3">
        <h3 className="font-black text-gray-900 flex items-center gap-2 flex-1">
          <Users className="w-4 h-4 text-emerald-700" /> Manajemen Pengguna
          {pagination && (
            <span className="text-xs font-semibold text-gray-400 ml-1">({pagination.total} total)</span>
          )}
        </h3>
        {/* Search */}
        <form onSubmit={handleSearch} className="flex items-center gap-2">
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
            <input
              type="text"
              value={searchInput}
              onChange={e => setSearchInput(e.target.value)}
              placeholder="Cari nama / email…"
              className="pl-8 pr-3 py-1.5 text-xs border border-gray-200 rounded-lg focus:outline-none focus:border-emerald-500 w-44"
            />
          </div>
          <button type="submit" className="px-3 py-1.5 text-xs font-bold bg-emerald-700 text-white rounded-lg hover:bg-emerald-600">
            Cari
          </button>
          {search && (
            <button type="button" onClick={() => { setSearch(""); setSearchInput(""); setPage(1); }}
              className="px-3 py-1.5 text-xs font-bold bg-gray-100 text-gray-600 rounded-lg hover:bg-gray-200">
              Reset
            </button>
          )}
        </form>
      </div>

      {/* Filters */}
      <div className="px-5 py-2.5 border-b border-gray-100 flex flex-wrap items-center gap-3 bg-gray-50/60">
        <div className="flex items-center gap-1.5 text-xs">
          <span className="text-gray-500 font-semibold">Peran:</span>
          {[["all","Semua"],["pekerja","Pekerja"],["perusahaan","Perusahaan"]].map(([v,l]) => (
            <button key={v} onClick={() => { setRoleFilter(v); setPage(1); }}
              className={`px-2.5 py-1 rounded-full text-[11px] font-bold transition-colors ${
                roleFilter === v ? "bg-emerald-700 text-white" : "bg-white border border-gray-200 text-gray-600 hover:border-emerald-400"
              }`}>{l}</button>
          ))}
        </div>
        <label className="flex items-center gap-1.5 text-xs text-gray-600 cursor-pointer select-none">
          <input type="checkbox" checked={onlySuspended} onChange={e => { setOnlySuspended(e.target.checked); setPage(1); }}
            className="accent-emerald-600 w-3.5 h-3.5" />
          <span className="font-semibold">Hanya Ditangguhkan</span>
        </label>
      </div>

      {/* Table */}
      {loading ? (
        <div className="py-16 flex justify-center"><Loader2 className="w-6 h-6 animate-spin text-emerald-600" /></div>
      ) : rows.length === 0 ? (
        <div className="py-16 text-center text-sm text-gray-400">
          {search ? `Tidak ada hasil untuk "${search}".` : "Belum ada pengguna terdaftar."}
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-gray-50 text-left text-[11px] uppercase tracking-wide text-gray-500">
                <th className="px-4 py-2.5 font-bold">Nama</th>
                <th className="px-4 py-2.5 font-bold">Email</th>
                <th className="px-4 py-2.5 font-bold">Peran</th>
                <th className="px-4 py-2.5 font-bold text-center">Rating ⚠</th>
                <th className="px-4 py-2.5 font-bold text-center">Status</th>
                <th className="px-4 py-2.5 font-bold text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {rows.map((u) => (
                <tr key={u.id} data-testid={`user-row-${u.id}`} className={u.suspended ? "bg-red-50/50" : "hover:bg-gray-50/60"}>
                  <td className="px-4 py-3 font-semibold text-gray-900">{u.displayName}</td>
                  <td className="px-4 py-3 text-gray-500 text-xs">{u.email}</td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-0.5 rounded-full text-[11px] font-bold ${
                      u.role === "perusahaan" ? "bg-blue-100 text-blue-700" : "bg-emerald-100 text-emerald-700"
                    }`}>
                      {u.role === "perusahaan" ? "Perusahaan" : "Pekerja"}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-center">
                    {u.negativeRatings > 0 ? (
                      <span className="inline-flex items-center gap-1 text-red-600 font-bold text-xs">
                        <AlertTriangle className="w-3.5 h-3.5" /> {u.negativeRatings}
                      </span>
                    ) : (
                      <span className="text-gray-300 text-xs">0</span>
                    )}
                  </td>
                  <td className="px-4 py-3 text-center">
                    {u.suspended ? (
                      <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-red-100 text-red-700">Ditangguhkan</span>
                    ) : (
                      <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-700">Aktif</span>
                    )}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <button
                      data-testid={`button-suspend-${u.id}`}
                      onClick={() => void handleToggle(u)}
                      disabled={busyId === u.id}
                      className={`inline-flex items-center gap-1.5 rounded-lg text-[11px] font-bold px-2.5 py-1.5 disabled:opacity-50 ${
                        u.suspended ? "bg-emerald-700 text-white hover:bg-emerald-600" : "bg-red-600 text-white hover:bg-red-500"
                      }`}
                    >
                      {busyId === u.id ? <Loader2 className="w-3 h-3 animate-spin" /> : u.suspended ? <CheckCircle2 className="w-3 h-3" /> : <Ban className="w-3 h-3" />}
                      {u.suspended ? "Aktifkan" : "Tangguhkan"}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Pagination controls */}
      {pagination && pagination.totalPages > 1 && (
        <div className="px-5 py-3 border-t border-gray-100 flex items-center justify-between gap-3">
          <span className="text-xs text-gray-400">
            Hal. {pagination.page} dari {pagination.totalPages} &nbsp;·&nbsp; {pagination.total} pengguna
          </span>
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setPage(p => Math.max(1, p - 1))}
              disabled={!pagination.hasPrev || loading}
              className="px-3 py-1.5 text-xs font-bold border border-gray-200 rounded-lg disabled:opacity-40 hover:bg-gray-50"
            >
              ← Sebelumnya
            </button>
            {/* Page number buttons — show at most 5 */}
            {Array.from({ length: Math.min(5, pagination.totalPages) }, (_, i) => {
              const start = Math.max(1, Math.min(pagination.page - 2, pagination.totalPages - 4));
              const pn = start + i;
              return (
                <button key={pn} onClick={() => setPage(pn)} disabled={loading}
                  className={`w-8 h-8 text-xs font-bold rounded-lg ${
                    pn === pagination.page ? "bg-emerald-700 text-white" : "border border-gray-200 hover:bg-gray-50 text-gray-600"
                  }`}>
                  {pn}
                </button>
              );
            })}
            <button
              onClick={() => setPage(p => Math.min(pagination.totalPages, p + 1))}
              disabled={!pagination.hasNext || loading}
              className="px-3 py-1.5 text-xs font-bold border border-gray-200 rounded-lg disabled:opacity-40 hover:bg-gray-50"
            >
              Berikutnya →
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// ── KYC verification queue ─────────────────────────────────────────
function KycTab() {
  const [rows, setRows] = useState<KycRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      setRows(await fetchKycQueue());
    } catch {
      /* keep last known rows */
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void load(); }, [load]);

  const handleDecision = async (userId: string, status: "verified" | "rejected") => {
    setBusyId(userId);
    try {
      const res = await verifyKyc(userId, status);
      setRows((prev) => prev.map((r) => (r.id === userId ? { ...r, verificationStatus: res.verificationStatus } : r)));
    } catch {
      /* ignore */
    } finally {
      setBusyId(null);
    }
  };

  const statusBadge = (s: KycRow["verificationStatus"]) => {
    const map: Record<KycRow["verificationStatus"], string> = {
      pending: "bg-amber-100 text-amber-700",
      verified: "bg-emerald-100 text-emerald-700",
      rejected: "bg-red-100 text-red-700",
      unverified: "bg-gray-100 text-gray-500",
    };
    const label: Record<KycRow["verificationStatus"], string> = {
      pending: "Menunggu",
      verified: "Terverifikasi",
      rejected: "Ditolak",
      unverified: "Belum Diajukan",
    };
    return <span className={`px-2 py-0.5 rounded-full text-[11px] font-bold ${map[s]}`}>{label[s]}</span>;
  };

  return (
    <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden shadow-sm">
      <div className="px-5 py-3.5 border-b border-gray-100">
        <h3 className="font-black text-gray-900 flex items-center gap-2">
          <IdCard className="w-4 h-4 text-emerald-700" /> Verifikasi Identitas (KYC)
        </h3>
      </div>
      {loading ? (
        <div className="py-16 flex justify-center"><Loader2 className="w-6 h-6 animate-spin text-emerald-600" /></div>
      ) : rows.length === 0 ? (
        <div className="py-16 text-center text-sm text-gray-400">Belum ada pengajuan verifikasi.</div>
      ) : (
        <div className="divide-y divide-gray-100">
          {rows.map((u) => (
            <div key={u.id} data-testid={`kyc-row-${u.id}`} className="px-5 py-4 flex flex-col md:flex-row md:items-center gap-3">
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-gray-900 text-sm">{u.name}</p>
                <p className="text-xs text-gray-500 truncate">{u.email}</p>
                <div className="mt-1">{statusBadge(u.verificationStatus)}</div>
              </div>
              <div className="flex items-center gap-2">
                {u.ktpPhotoUrl && (
                  <a href={u.ktpPhotoUrl} target="_blank" rel="noreferrer" className="flex items-center gap-1.5 rounded-lg bg-gray-50 border border-gray-200 px-2.5 py-1.5 text-[11px] font-bold text-gray-600 hover:bg-gray-100">
                    <ExternalLink className="w-3 h-3" /> Foto KTP
                  </a>
                )}
                {u.selfieWithKtpUrl && (
                  <a href={u.selfieWithKtpUrl} target="_blank" rel="noreferrer" className="flex items-center gap-1.5 rounded-lg bg-gray-50 border border-gray-200 px-2.5 py-1.5 text-[11px] font-bold text-gray-600 hover:bg-gray-100">
                    <ExternalLink className="w-3 h-3" /> Selfie+KTP
                  </a>
                )}
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <button
                  data-testid={`button-kyc-verify-${u.id}`}
                  onClick={() => void handleDecision(u.id, "verified")}
                  disabled={busyId === u.id || u.verificationStatus === "verified"}
                  className="inline-flex items-center gap-1.5 rounded-lg text-[11px] font-bold px-2.5 py-1.5 disabled:opacity-40 bg-emerald-700 text-white hover:bg-emerald-600"
                >
                  {busyId === u.id ? <Loader2 className="w-3 h-3 animate-spin" /> : <ShieldCheck className="w-3 h-3" />}
                  Verifikasi
                </button>
                <button
                  data-testid={`button-kyc-reject-${u.id}`}
                  onClick={() => void handleDecision(u.id, "rejected")}
                  disabled={busyId === u.id || u.verificationStatus === "rejected"}
                  className="inline-flex items-center gap-1.5 rounded-lg text-[11px] font-bold px-2.5 py-1.5 disabled:opacity-40 bg-red-600 text-white hover:bg-red-500"
                >
                  {busyId === u.id ? <Loader2 className="w-3 h-3 animate-spin" /> : <XCircle className="w-3 h-3" />}
                  Tolak
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ── Tab 3: Operator training academy ──────────────────────────────
function formatDateTime(iso: string): string {
  return new Date(iso).toLocaleString("id-ID", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

// ── Question editor form ───────────────────────────────────────────
const EMPTY_FORM: QuestionInput = {
  category: "",
  prompt: "",
  options: ["", ""],
  correctIndex: 0,
  explanation: "",
  sortOrder: 0,
};

function QuestionForm({
  initial,
  onSave,
  onCancel,
  saving,
}: {
  initial: QuestionInput;
  onSave: (data: QuestionInput) => void;
  onCancel: () => void;
  saving: boolean;
}) {
  const [form, setForm] = useState<QuestionInput>({ ...initial });

  const setOption = (i: number, val: string) =>
    setForm((f) => {
      const opts = [...f.options];
      opts[i] = val;
      return { ...f, options: opts };
    });

  const addOption = () =>
    setForm((f) => ({ ...f, options: [...f.options, ""] }));

  const removeOption = (i: number) =>
    setForm((f) => {
      const opts = f.options.filter((_, idx) => idx !== i);
      return {
        ...f,
        options: opts,
        correctIndex: Math.min(f.correctIndex, opts.length - 1),
      };
    });

  const valid =
    form.category.trim() &&
    form.prompt.trim() &&
    form.options.length >= 2 &&
    form.options.every((o) => o.trim()) &&
    form.correctIndex < form.options.length;

  return (
    <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 space-y-3">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div>
          <label className="text-[11px] font-bold uppercase tracking-wide text-gray-500 block mb-1">Kategori</label>
          <input
            type="text"
            value={form.category}
            onChange={(e) => setForm((f) => ({ ...f, category: e.target.value }))}
            placeholder="mis. Escrow, Broadcast, Upah…"
            className="w-full rounded-xl border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
          />
        </div>
        <div>
          <label className="text-[11px] font-bold uppercase tracking-wide text-gray-500 block mb-1">Urutan</label>
          <input
            type="number"
            value={form.sortOrder}
            onChange={(e) => setForm((f) => ({ ...f, sortOrder: Number(e.target.value) }))}
            className="w-full rounded-xl border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
          />
        </div>
      </div>

      <div>
        <label className="text-[11px] font-bold uppercase tracking-wide text-gray-500 block mb-1">Pertanyaan</label>
        <textarea
          value={form.prompt}
          onChange={(e) => setForm((f) => ({ ...f, prompt: e.target.value }))}
          rows={2}
          placeholder="Tulis pertanyaan di sini…"
          className="w-full rounded-xl border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 resize-none"
        />
      </div>

      <div>
        <label className="text-[11px] font-bold uppercase tracking-wide text-gray-500 block mb-1">
          Pilihan Jawaban <span className="text-gray-400 font-normal">(tandai jawaban benar dengan radio)</span>
        </label>
        <div className="space-y-2">
          {form.options.map((opt, i) => (
            <div key={i} className="flex items-center gap-2">
              <input
                type="radio"
                name="correctIndex"
                checked={form.correctIndex === i}
                onChange={() => setForm((f) => ({ ...f, correctIndex: i }))}
                className="accent-emerald-600 w-4 h-4 flex-shrink-0"
              />
              <input
                type="text"
                value={opt}
                onChange={(e) => setOption(i, e.target.value)}
                placeholder={`Opsi ${i + 1}`}
                className="flex-1 rounded-xl border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
              {form.options.length > 2 && (
                <button
                  type="button"
                  onClick={() => removeOption(i)}
                  className="p-1.5 rounded-lg text-red-400 hover:bg-red-50"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          ))}
        </div>
        {form.options.length < 8 && (
          <button
            type="button"
            onClick={addOption}
            className="mt-2 inline-flex items-center gap-1 text-xs font-bold text-emerald-700 hover:text-emerald-600"
          >
            <Plus className="w-3.5 h-3.5" /> Tambah Opsi
          </button>
        )}
      </div>

      <div>
        <label className="text-[11px] font-bold uppercase tracking-wide text-gray-500 block mb-1">
          Penjelasan <span className="text-gray-400 font-normal">(tampil setelah kuis selesai)</span>
        </label>
        <textarea
          value={form.explanation}
          onChange={(e) => setForm((f) => ({ ...f, explanation: e.target.value }))}
          rows={2}
          placeholder="Jelaskan mengapa jawaban tersebut benar…"
          className="w-full rounded-xl border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 resize-none"
        />
      </div>

      <div className="flex items-center gap-3 pt-1">
        <button
          type="button"
          onClick={() => onSave(form)}
          disabled={!valid || saving}
          className="inline-flex items-center gap-2 rounded-xl bg-emerald-700 text-white text-sm font-bold px-4 py-2.5 hover:bg-emerald-600 disabled:opacity-50"
        >
          {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
          Simpan
        </button>
        <button
          type="button"
          onClick={onCancel}
          className="text-sm font-bold text-gray-500 hover:text-gray-700"
        >
          Batal
        </button>
      </div>
    </div>
  );
}

// ── Question editor panel ─────────────────────────────────────────
function QuestionEditor({
  passingScore,
  onPassingScoreChange,
}: {
  passingScore: number;
  onPassingScoreChange: (score: number) => void;
}) {
  const [questions, setQuestions] = useState<AdminAcademyQuestion[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingId, setEditingId] = useState<number | "new" | null>(null);
  const [saving, setSaving] = useState(false);
  const [deletingId, setDeletingId] = useState<number | null>(null);
  const [scoreInput, setScoreInput] = useState(String(passingScore));
  const [savingScore, setSavingScore] = useState(false);
  const [scoreError, setScoreError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      setQuestions(await fetchAcademyQuestions());
    } catch {
      /* keep last state */
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    setScoreInput(String(passingScore));
  }, [passingScore]);

  const handleSaveQuestion = async (id: number | "new", data: QuestionInput) => {
    setSaving(true);
    try {
      if (id === "new") {
        const created = await createAcademyQuestion(data);
        setQuestions((qs) => [...qs, created]);
      } else {
        const updated = await updateAcademyQuestion(id, data);
        setQuestions((qs) => qs.map((q) => (q.id === id ? updated : q)));
      }
      setEditingId(null);
    } catch {
      /* keep form open */
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: number) => {
    if (!window.confirm("Hapus soal ini? Tindakan tidak bisa dibatalkan.")) return;
    setDeletingId(id);
    try {
      await deleteAcademyQuestion(id);
      setQuestions((qs) => qs.filter((q) => q.id !== id));
    } catch {
      /* ignore */
    } finally {
      setDeletingId(null);
    }
  };

  const handleSaveScore = async () => {
    const val = Number(scoreInput);
    if (!Number.isFinite(val) || val < 1 || val > 100) {
      setScoreError("Masukkan angka antara 1–100.");
      return;
    }
    setScoreError(null);
    setSavingScore(true);
    try {
      const res = await updateAcademySettings(val);
      onPassingScoreChange(res.passingScore);
    } catch {
      setScoreError("Gagal menyimpan. Coba lagi.");
    } finally {
      setSavingScore(false);
    }
  };

  if (loading) {
    return (
      <div className="py-12 flex justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-emerald-600" />
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {/* Passing score */}
      <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-5">
        <h3 className="font-black text-gray-900 flex items-center gap-2 mb-1">
          <Settings2 className="w-4 h-4 text-emerald-700" /> Pengaturan Nilai Lulus
        </h3>
        <p className="text-xs text-gray-500 mb-3">Persentase minimum jawaban benar yang diperlukan untuk lulus asesmen.</p>
        <div className="flex items-center gap-3">
          <div className="relative">
            <input
              type="number"
              min={1}
              max={100}
              value={scoreInput}
              onChange={(e) => { setScoreInput(e.target.value); setScoreError(null); }}
              className="w-24 rounded-xl border border-gray-200 px-3 py-2 text-sm font-bold text-gray-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 pr-7"
            />
            <span className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs font-bold text-gray-400">%</span>
          </div>
          <button
            onClick={() => void handleSaveScore()}
            disabled={savingScore}
            className="inline-flex items-center gap-2 rounded-xl bg-emerald-700 text-white text-sm font-bold px-4 py-2.5 hover:bg-emerald-600 disabled:opacity-50"
          >
            {savingScore ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            Simpan
          </button>
        </div>
        {scoreError && <p className="text-xs text-red-600 mt-2">{scoreError}</p>}
      </div>

      {/* Question list */}
      <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-5 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-black text-gray-900 flex items-center gap-2">
            <ClipboardList className="w-4 h-4 text-emerald-700" /> Bank Soal ({questions.length} soal)
          </h3>
          {editingId !== "new" && (
            <button
              onClick={() => setEditingId("new")}
              className="inline-flex items-center gap-1.5 rounded-xl bg-emerald-700 text-white text-xs font-bold px-3 py-2 hover:bg-emerald-600"
            >
              <Plus className="w-3.5 h-3.5" /> Tambah Soal
            </button>
          )}
        </div>

        {editingId === "new" && (
          <QuestionForm
            initial={{ ...EMPTY_FORM, sortOrder: questions.length }}
            onSave={(data) => void handleSaveQuestion("new", data)}
            onCancel={() => setEditingId(null)}
            saving={saving}
          />
        )}

        {questions.length === 0 && editingId !== "new" ? (
          <div className="rounded-xl border-2 border-dashed border-gray-200 py-10 text-center">
            <GraduationCap className="w-8 h-8 text-gray-300 mx-auto mb-2" />
            <p className="text-sm text-gray-400">Belum ada soal — klik "Tambah Soal" untuk mulai.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {questions.map((q, qi) => (
              <div key={q.id}>
                {editingId === q.id ? (
                  <QuestionForm
                    initial={{
                      category: q.category,
                      prompt: q.prompt,
                      options: q.options,
                      correctIndex: q.correctIndex,
                      explanation: q.explanation,
                      sortOrder: q.sortOrder,
                    }}
                    onSave={(data) => void handleSaveQuestion(q.id, data)}
                    onCancel={() => setEditingId(null)}
                    saving={saving}
                  />
                ) : (
                  <div className="rounded-xl border border-gray-100 bg-gray-50 px-4 py-3">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1 min-w-0">
                        <p className="text-[10px] font-bold uppercase tracking-wide text-emerald-700 mb-0.5">{q.category}</p>
                        <p className="text-sm font-semibold text-gray-900">
                          {qi + 1}. {q.prompt}
                        </p>
                        <div className="mt-1.5 space-y-0.5">
                          {q.options.map((opt, oi) => (
                            <p key={oi} className={`text-xs ${oi === q.correctIndex ? "text-emerald-700 font-bold" : "text-gray-500"}`}>
                              {oi === q.correctIndex ? "✓ " : "· "}{opt}
                            </p>
                          ))}
                        </div>
                        {q.explanation && (
                          <p className="text-[11px] text-gray-400 mt-1 italic">{q.explanation}</p>
                        )}
                      </div>
                      <div className="flex items-center gap-1 flex-shrink-0">
                        <button
                          onClick={() => setEditingId(q.id)}
                          className="p-1.5 rounded-lg text-gray-400 hover:text-emerald-700 hover:bg-emerald-50"
                          title="Edit soal"
                        >
                          <Pencil className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => void handleDelete(q.id)}
                          disabled={deletingId === q.id}
                          className="p-1.5 rounded-lg text-gray-400 hover:text-red-600 hover:bg-red-50 disabled:opacity-50"
                          title="Hapus soal"
                        >
                          {deletingId === q.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// ── Main AcademyTab ───────────────────────────────────────────────
function AcademyTab({ onTrainingPassed }: { onTrainingPassed?: () => void }) {
  const [questions, setQuestions] = useState<AcademyQuestion[]>([]);
  const [completions, setCompletions] = useState<AcademyCompletion[]>([]);
  const [passingScore, setPassingScore] = useState(80);
  const [loading, setLoading] = useState(true);
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState<AcademyResult | null>(null);
  const [taking, setTaking] = useState(false);
  const [editorMode, setEditorMode] = useState(false);

  const load = useCallback(async () => {
    try {
      const data = await fetchAcademy();
      setQuestions(data.questions);
      setCompletions(data.completions);
      setPassingScore(data.passingScore);
    } catch {
      /* keep last known state */
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const startQuiz = () => {
    setAnswers({});
    setResult(null);
    setTaking(true);
  };

  const answeredCount = Object.keys(answers).length;
  const allAnswered = questions.length > 0 && answeredCount === questions.length;

  const handleSubmit = async () => {
    if (!allAnswered || submitting) return;
    setSubmitting(true);
    try {
      const payload = questions.map((q) => ({
        questionId: q.id,
        selectedIndex: answers[q.id],
      }));
      const res = await submitAcademy(payload);
      setResult(res);
      setTaking(false);
      await load();
      if (res.passed) {
        onTrainingPassed?.();
      }
    } catch {
      /* leave the quiz open so the operator can retry */
    } finally {
      setSubmitting(false);
    }
  };

  const bestScore = completions.reduce((m, c) => Math.max(m, c.score), 0);
  const hasPassed = completions.some((c) => c.passed);

  if (loading) {
    return (
      <div className="py-16 flex justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-emerald-600" />
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {/* Mode toggle */}
      <div className="flex items-center justify-between">
        <div className="flex rounded-xl overflow-hidden border border-gray-200">
          <button
            onClick={() => { setEditorMode(false); setTaking(false); }}
            className={`px-4 py-2 text-sm font-bold transition-colors ${!editorMode ? "bg-emerald-700 text-white" : "bg-white text-gray-600 hover:bg-gray-50"}`}
          >
            <span className="inline-flex items-center gap-1.5"><GraduationCap className="w-3.5 h-3.5" /> Asesmen</span>
          </button>
          <button
            onClick={() => { setEditorMode(true); setTaking(false); }}
            className={`px-4 py-2 text-sm font-bold transition-colors border-l border-gray-200 ${editorMode ? "bg-emerald-700 text-white" : "bg-white text-gray-600 hover:bg-gray-50"}`}
          >
            <span className="inline-flex items-center gap-1.5"><Settings2 className="w-3.5 h-3.5" /> Editor Soal</span>
          </button>
        </div>
        {!editorMode && !taking && (
          <button
            onClick={() => void load()}
            className="p-2 rounded-xl text-gray-400 hover:text-gray-600 hover:bg-gray-100"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* ── Editor mode ── */}
      {editorMode ? (
        <QuestionEditor
          passingScore={passingScore}
          onPassingScoreChange={(s) => { setPassingScore(s); void load(); }}
        />
      ) : (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <SummaryCard label="Nilai Lulus Minimum" value={`${passingScore}%`} tone="amber" />
            <SummaryCard label="Skor Terbaik Anda" value={completions.length ? `${bestScore}%` : "—"} tone="gold" />
            <SummaryCard label="Total Percobaan" value={String(completions.length)} tone="emerald" />
          </div>

          {/* Result banner */}
          {result && (
            <div
              data-testid="academy-result"
              className={`rounded-2xl border p-5 shadow-sm ${
                result.passed ? "bg-emerald-50 border-emerald-200" : "bg-amber-50 border-amber-200"
              }`}
            >
              <div className="flex items-center gap-3">
                {result.passed ? (
                  <Award className="w-8 h-8 text-emerald-600" />
                ) : (
                  <AlertTriangle className="w-8 h-8 text-amber-500" />
                )}
                <div>
                  <p className="font-black text-gray-900">
                    {result.passed ? "Selamat, Anda Lulus!" : "Belum Lulus"}
                  </p>
                  <p className="text-sm text-gray-600">
                    Skor {result.score}% · {result.correct}/{result.total} benar
                    {" · "}Batas lulus {result.passingScore}%
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Quiz taking view */}
          {taking ? (
            <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-5 space-y-5">
              <div className="flex items-center justify-between">
                <h3 className="font-black text-gray-900 flex items-center gap-2">
                  <GraduationCap className="w-4 h-4 text-emerald-700" /> Asesmen Operator
                </h3>
                <span className="text-xs font-bold text-gray-500">
                  {answeredCount}/{questions.length} terjawab
                </span>
              </div>

              {questions.map((q, qi) => (
                <div key={q.id} data-testid={`question-${q.id}`} className="border-t border-gray-100 pt-4 first:border-t-0 first:pt-0">
                  <p className="text-[11px] font-bold uppercase tracking-wide text-emerald-700">{q.category}</p>
                  <p className="font-semibold text-gray-900 mt-0.5">
                    {qi + 1}. {q.prompt}
                  </p>
                  <div className="mt-3 space-y-2">
                    {q.options.map((opt, oi) => {
                      const selected = answers[q.id] === oi;
                      return (
                        <button
                          key={oi}
                          data-testid={`option-${q.id}-${oi}`}
                          onClick={() => setAnswers((a) => ({ ...a, [q.id]: oi }))}
                          className={`w-full text-left rounded-xl border px-3.5 py-2.5 text-sm transition-colors ${
                            selected
                              ? "border-emerald-600 bg-emerald-50 font-semibold text-emerald-900"
                              : "border-gray-200 hover:bg-gray-50 text-gray-700"
                          }`}
                        >
                          <span className="inline-flex items-center gap-2">
                            <span
                              className={`w-4 h-4 rounded-full border flex-shrink-0 ${
                                selected ? "border-emerald-600 bg-emerald-600" : "border-gray-300"
                              }`}
                            />
                            {opt}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}

              <div className="flex items-center gap-3 pt-2">
                <button
                  data-testid="button-submit-quiz"
                  onClick={() => void handleSubmit()}
                  disabled={!allAnswered || submitting}
                  className="inline-flex items-center gap-2 rounded-xl bg-emerald-700 text-white text-sm font-bold px-4 py-2.5 hover:bg-emerald-600 disabled:opacity-50"
                >
                  {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle2 className="w-4 h-4" />}
                  Kirim Jawaban
                </button>
                <button
                  onClick={() => setTaking(false)}
                  className="text-sm font-bold text-gray-500 hover:text-gray-700"
                >
                  Batal
                </button>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {/* Start / review card */}
              <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-5">
                <h3 className="font-black text-gray-900 flex items-center gap-2 mb-1">
                  <GraduationCap className="w-4 h-4 text-emerald-700" /> Asesmen Onboarding Operator
                </h3>
                <p className="text-xs text-gray-500 mb-4">
                  {questions.length} soal seputar escrow, broadcast, presensi, dan moderasi. Nilai lulus {passingScore}%.
                </p>

                {hasPassed && !result && (
                  <div className="mb-4 flex items-center gap-2 rounded-xl bg-emerald-50 border border-emerald-200 px-3.5 py-2.5">
                    <Trophy className="w-4 h-4 text-emerald-600" />
                    <p className="text-sm font-semibold text-emerald-800">Anda sudah lulus asesmen ini.</p>
                  </div>
                )}

                <button
                  data-testid="button-start-quiz"
                  onClick={startQuiz}
                  className="inline-flex items-center gap-2 rounded-xl bg-emerald-700 text-white text-sm font-bold px-4 py-2.5 hover:bg-emerald-600"
                >
                  {completions.length ? <RotateCcw className="w-4 h-4" /> : <Zap className="w-4 h-4" />}
                  {completions.length ? "Ulangi Asesmen" : "Mulai Asesmen"}
                </button>

                {result && (
                  <div className="mt-5 space-y-2.5 border-t border-gray-100 pt-4">
                    <p className="text-xs font-bold uppercase tracking-wide text-gray-500">Pembahasan</p>
                    {result.answers.map((a, i) => {
                      const q = questions.find((qq) => qq.id === a.questionId);
                      return (
                        <div key={a.questionId} className="flex items-start gap-2 text-sm">
                          {a.correct ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-600 mt-0.5 flex-shrink-0" />
                          ) : (
                            <XCircle className="w-4 h-4 text-red-500 mt-0.5 flex-shrink-0" />
                          )}
                          <div>
                            <p className="font-semibold text-gray-800">
                              {i + 1}. {q?.prompt ?? a.questionId}
                            </p>
                            {!a.correct && (
                              <p className="text-[13px] text-emerald-800">
                                Jawaban benar: {q?.options[a.correctIndex] ?? "—"}
                              </p>
                            )}
                            <p className="text-[12px] text-gray-500">{a.explanation}</p>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Completion history */}
              <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-5">
                <h3 className="font-black text-gray-900 flex items-center gap-2 mb-1">
                  <ClipboardList className="w-4 h-4 text-emerald-700" /> Riwayat Penyelesaian
                </h3>
                <p className="text-xs text-gray-500 mb-4">Rekam jejak asesmen yang telah Anda selesaikan.</p>

                {completions.length === 0 ? (
                  <div className="rounded-xl border-2 border-dashed border-gray-200 py-12 text-center">
                    <GraduationCap className="w-8 h-8 text-gray-300 mx-auto mb-2" />
                    <p className="text-sm text-gray-400">Belum ada percobaan — mulai asesmen pertama Anda.</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {completions.map((c) => (
                      <div
                        key={c.id}
                        data-testid={`completion-${c.id}`}
                        className="flex items-center justify-between rounded-xl border border-gray-100 px-3.5 py-2.5"
                      >
                        <div>
                          <p className="font-bold text-gray-900 text-sm">{c.score}% <span className="font-normal text-gray-400">({c.correct}/{c.total})</span></p>
                          <p className="text-[11px] text-gray-400">{formatDateTime(c.completedAt)}</p>
                        </div>
                        {c.passed ? (
                          <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 text-emerald-700 text-[11px] font-bold px-2.5 py-1">
                            <CheckCircle2 className="w-3.5 h-3.5" /> Lulus
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 rounded-full bg-red-50 text-red-600 text-[11px] font-bold px-2.5 py-1">
                            <XCircle className="w-3.5 h-3.5" /> Belum Lulus
                          </span>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

// ── Tab: Pusat Resolusi (remote disputes) ─────────────────────────
function ResolutionTab() {
  const [rows, setRows] = useState<DisputeRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState<number | null>(null);

  const load = useCallback(async () => {
    try {
      setRows(await fetchDisputes());
    } catch {
      /* keep last known rows */
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
    const ws = new RealtimeSocket({ admin: true });
    ws.onmessage = (ev) => {
      try {
        const msg = JSON.parse(ev.data) as { type?: string };
        if (msg.type === "gig_broadcast") void load();
      } catch {
        /* ignore malformed frames */
      }
    };
    return () => ws.close();
  }, [load]);

  const decide = async (jobId: number, action: "release" | "refund") => {
    setBusyId(jobId);
    try {
      if (action === "release") await forceRelease(jobId);
      else await refund(jobId);
      await load();
    } catch {
      /* the reload will reflect the true state */
    } finally {
      setBusyId(null);
    }
  };

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-4 flex items-start gap-3">
        <div className="w-9 h-9 rounded-xl bg-amber-100 flex items-center justify-center shrink-0">
          <Gavel className="w-5 h-5 text-amber-700" />
        </div>
        <div>
          <h3 className="font-black text-gray-900">Pusat Resolusi Sengketa Remote</h3>
          <p className="text-xs text-gray-500 mt-0.5">
            Proyek remote yang bukti kerjanya ditolak employer &amp; dibekukan (escrow terkunci). Putuskan pemenang sengketa.
          </p>
        </div>
      </div>

      {loading ? (
        <div className="py-16 flex justify-center"><Loader2 className="w-6 h-6 animate-spin text-emerald-600" /></div>
      ) : rows.length === 0 ? (
        <div className="bg-white rounded-2xl border border-gray-200 shadow-sm py-16 text-center text-sm text-gray-400">
          Tidak ada sengketa aktif.
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {rows.map((r) => (
            <div
              key={r.jobId}
              data-testid={`dispute-row-${r.jobId}`}
              className="bg-white rounded-2xl border border-amber-200 shadow-sm p-5"
            >
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="font-black text-gray-900">{r.posisi}</p>
                  <p className="text-[11px] text-gray-400 font-mono">Job #{r.jobId}</p>
                </div>
                <span className="inline-block px-2.5 py-1 rounded-full text-[11px] font-bold bg-red-100 text-red-700 border border-red-200">
                  Dibekukan (Sengketa)
                </span>
              </div>

              <div className="mt-3 space-y-1.5 text-sm">
                <div className="flex justify-between gap-4">
                  <span className="text-gray-500">Employer</span>
                  <span className="font-semibold text-gray-900 text-right">{r.employerName}</span>
                </div>
                <div className="flex justify-between gap-4">
                  <span className="text-gray-500">Employer ID</span>
                  <span className="font-mono text-[11px] text-gray-600 text-right">{r.employerId ?? "—"}</span>
                </div>
                <div className="flex justify-between gap-4">
                  <span className="text-gray-500">Escrow Terkunci</span>
                  <span className="font-bold text-emerald-700 text-right">{formatRp(r.escrowAmount)}</span>
                </div>
                <div className="flex justify-between gap-4">
                  <span className="text-gray-500">Hak Pekerja (net)</span>
                  <span className="font-semibold text-gray-700 text-right">{formatRp(r.workerNet)}</span>
                </div>
              </div>

              <div className="mt-3">
                {r.proofUrl ? (
                  <a
                    data-testid={`dispute-proof-${r.jobId}`}
                    href={r.proofUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-blue-600 hover:text-blue-800 break-all"
                  >
                    <ExternalLink className="w-3.5 h-3.5 shrink-0" /> Lihat Bukti Kerja (Project Link)
                  </a>
                ) : (
                  <span className="text-xs text-gray-400 italic">Tidak ada link bukti terlampir.</span>
                )}
              </div>

              <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-2">
                <button
                  data-testid={`button-release-worker-${r.jobId}`}
                  onClick={() => void decide(r.jobId, "release")}
                  disabled={busyId === r.jobId}
                  className="inline-flex items-center justify-center gap-1.5 rounded-xl bg-emerald-700 text-white text-xs font-bold px-3 py-2.5 hover:bg-emerald-600 disabled:opacity-50"
                >
                  {busyId === r.jobId ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Scale className="w-3.5 h-3.5" />}
                  Putuskan Cairkan ke Pekerja
                </button>
                <button
                  data-testid={`button-refund-employer-${r.jobId}`}
                  onClick={() => void decide(r.jobId, "refund")}
                  disabled={busyId === r.jobId}
                  className="inline-flex items-center justify-center gap-1.5 rounded-xl bg-amber-600 text-white text-xs font-bold px-3 py-2.5 hover:bg-amber-500 disabled:opacity-50"
                >
                  {busyId === r.jobId ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Scale className="w-3.5 h-3.5" />}
                  Putuskan Refund ke Employer
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ── Tab: Monitoring Proyek Fisik (on-site tracker) ────────────────
function OnsiteTab() {
  const [data, setData] = useState<OnsiteData>({ gigs: [], payouts: [] });
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    try {
      setData(await fetchOnsite());
    } catch {
      /* keep last known data */
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
    const ws = new RealtimeSocket({ admin: true });
    ws.onmessage = (ev) => {
      try {
        const msg = JSON.parse(ev.data) as { type?: string };
        if (msg.type === "daily_payout" || msg.type === "gig_broadcast") void load();
      } catch {
        /* ignore malformed frames */
      }
    };
    return () => ws.close();
  }, [load]);

  return (
    <div className="space-y-5">
      <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-4 flex items-start gap-3">
        <div className="w-9 h-9 rounded-xl bg-emerald-100 flex items-center justify-center shrink-0">
          <HardHat className="w-5 h-5 text-emerald-700" />
        </div>
        <div>
          <h3 className="font-black text-gray-900">Monitoring Proyek Fisik (On-Site)</h3>
          <p className="text-xs text-gray-500 mt-0.5">
            Progres durasi borongan fisik &amp; log pencairan upah harian via QR Check-out.
          </p>
        </div>
        <button
          onClick={() => void load()}
          className="ml-auto flex items-center gap-1.5 text-xs font-bold text-emerald-700 hover:text-emerald-900 shrink-0"
        >
          <RefreshCw className="w-3.5 h-3.5" /> Segarkan
        </button>
      </div>

      {loading ? (
        <div className="py-16 flex justify-center"><Loader2 className="w-6 h-6 animate-spin text-emerald-600" /></div>
      ) : (
        <>
          {data.gigs.length === 0 ? (
            <div className="bg-white rounded-2xl border border-gray-200 shadow-sm py-16 text-center text-sm text-gray-400">
              Belum ada proyek fisik aktif.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {data.gigs.map((g) => {
                const total = Math.max(1, g.jumlahHari);
                const pct = Math.min(100, Math.round((g.daysPaid / total) * 100));
                return (
                  <div
                    key={g.jobId}
                    data-testid={`onsite-gig-${g.jobId}`}
                    className="bg-white rounded-2xl border border-gray-200 shadow-sm p-5"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <p className="font-black text-gray-900">{g.posisi}</p>
                        <p className="text-xs text-gray-500 flex items-center gap-1">
                          <Building2 className="w-3 h-3" /> {g.employerName}
                        </p>
                      </div>
                      <span className="inline-block px-2.5 py-1 rounded-full text-[11px] font-bold bg-blue-100 text-blue-700 border border-blue-200">
                        {g.escrowStatus}
                      </span>
                    </div>

                    {g.alamat && (
                      <p className="text-[11px] text-gray-400 mt-1.5">{g.alamat}</p>
                    )}

                    <div className="mt-4">
                      <div className="flex justify-between text-xs font-bold mb-1.5">
                        <span className="text-gray-700">Hari ke-{g.daysPaid} dari {g.jumlahHari}</span>
                        <span className="text-emerald-700">{pct}%</span>
                      </div>
                      <div className="h-2.5 rounded-full bg-gray-100 overflow-hidden">
                        <div
                          className="h-full rounded-full bg-gradient-to-r from-emerald-600 to-emerald-500 transition-all"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>

                    <div className="mt-3 flex justify-between text-xs">
                      <span className="text-gray-500">Total Escrow</span>
                      <span className="font-bold text-gray-900">{formatRp(g.escrowAmount)}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden shadow-sm">
            <div className="px-5 py-3.5 border-b border-gray-100">
              <h3 className="font-black text-gray-900 flex items-center gap-2">
                <Zap className="w-4 h-4 text-emerald-700" /> Log Pencairan Harian (QR)
              </h3>
            </div>
            {data.payouts.length === 0 ? (
              <div className="py-12 text-center text-sm text-gray-400">Belum ada pencairan harian.</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-gray-50 text-left text-[11px] uppercase tracking-wide text-gray-500">
                      <th className="px-4 py-2.5 font-bold">Pekerja</th>
                      <th className="px-4 py-2.5 font-bold">Job ID</th>
                      <th className="px-4 py-2.5 font-bold">Hari ke-</th>
                      <th className="px-4 py-2.5 font-bold text-right">Bruto</th>
                      <th className="px-4 py-2.5 font-bold text-right">Bagian Platform (Legacy)</th>
                      <th className="px-4 py-2.5 font-bold text-right">Net Pekerja</th>
                      <th className="px-4 py-2.5 font-bold">Waktu</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {data.payouts.map((p) => (
                      <tr key={p.id} data-testid={`payout-row-${p.id}`} className="hover:bg-gray-50/60">
                        <td className="px-4 py-3 font-semibold text-gray-900">{p.workerName}</td>
                        <td className="px-4 py-3 font-mono text-[11px] text-gray-500">{p.jobId}</td>
                        <td className="px-4 py-3 text-gray-700">Hari ke-{p.dayIndex}</td>
                        <td className="px-4 py-3 text-right text-gray-600">{formatRp(p.grossFraction)}</td>
                        <td className="px-4 py-3 text-right text-red-600">− {formatRp(p.platformFee)}</td>
                        <td className="px-4 py-3 text-right font-bold text-emerald-700">{formatRp(p.netToWorker)}</td>
                        <td className="px-4 py-3 text-[11px] text-gray-400">
                          {new Date(p.at).toLocaleString("id-ID")}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}

// ── Confirmation Modal ────────────────────────────────────────────
function ConfirmModal({
  title,
  description,
  confirmLabel,
  confirmColor,
  onConfirm,
  onClose,
  busy,
}: {
  title: string;
  description: string;
  confirmLabel: string;
  confirmColor: string;
  onConfirm: (reason: string) => void;
  onClose: () => void;
  busy: boolean;
}) {
  const [reason, setReason] = useState("");
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center px-4" style={{ background: "rgba(0,0,0,0.55)" }}>
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6 space-y-4">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h3 className="font-black text-gray-900 text-base">{title}</h3>
            <p className="text-sm text-gray-500 mt-0.5">{description}</p>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 shrink-0">
            <X className="w-5 h-5" />
          </button>
        </div>
        <div>
          <label className="text-[11px] font-bold uppercase tracking-wide text-gray-500 block mb-1">
            Alasan / Catatan (wajib)
          </label>
          <textarea
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            rows={3}
            placeholder="Jelaskan alasan tindakan ini..."
            className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm text-gray-800 placeholder-gray-300 focus:outline-none focus:ring-2 focus:ring-emerald-400/50 resize-none"
          />
        </div>
        <div className="flex gap-2 justify-end">
          <button
            onClick={onClose}
            disabled={busy}
            className="px-4 py-2 rounded-xl text-sm font-bold text-gray-600 border border-gray-200 hover:bg-gray-50 disabled:opacity-50"
          >
            Batal
          </button>
          <button
            onClick={() => onConfirm(reason.trim())}
            disabled={busy || !reason.trim()}
            className="px-4 py-2 rounded-xl text-sm font-bold text-white disabled:opacity-50 flex items-center gap-1.5"
            style={{ background: confirmColor }}
          >
            {busy && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Tab: Job Management ───────────────────────────────────────────
type JobAction = { jobId: number; posisi: string; kind: "delete" | "refund" | "payout" } | null;

function JobsTab() {
  const [rows, setRows] = useState<JobManagementRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [action, setAction] = useState<JobAction>(null);
  const [busy, setBusy] = useState(false);
  const [toast, setToast] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      setRows(await fetchAdminJobs());
    } catch {
      /* keep last rows */
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void load(); }, [load]);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  };

  const handleConfirm = async (reason: string) => {
    if (!action) return;
    setBusy(true);
    try {
      if (action.kind === "delete") await deleteAdminJob(action.jobId, reason);
      else if (action.kind === "refund") await refundAdminJob(action.jobId, reason);
      else await forcePayoutAdminJob(action.jobId, reason);

      showToast(
        action.kind === "delete"
          ? "Job berhasil dihapus."
          : action.kind === "refund"
          ? "Escrow berhasil direfund ke pemberi kerja."
          : "Pembayaran paksa ke pekerja berhasil.",
      );
      setAction(null);
      await load();
    } catch (err) {
      showToast(err instanceof AdminError ? err.message : "Terjadi kesalahan.");
    } finally {
      setBusy(false);
    }
  };

  const escrowStatusLabel = (s: string) => {
    const map: Record<string, { label: string; cls: string }> = {
      locked: { label: "Terkunci", cls: "bg-amber-100 text-amber-800 border-amber-200" },
      released: { label: "Cair", cls: "bg-emerald-100 text-emerald-800 border-emerald-200" },
      refunded: { label: "Direfund", cls: "bg-blue-100 text-blue-800 border-blue-200" },
      disputed_active: { label: "Sengketa", cls: "bg-red-100 text-red-800 border-red-200" },
    };
    const d = map[s] ?? { label: s, cls: "bg-gray-100 text-gray-700 border-gray-200" };
    return (
      <span className={`inline-block px-2 py-0.5 rounded-full text-[11px] font-bold border ${d.cls}`}>
        {d.label}
      </span>
    );
  };

  const modalMeta = action
    ? action.kind === "delete"
      ? {
          title: "Hapus Job Posting",
          description: `Anda akan menghapus job "${action.posisi}" (ID: ${action.jobId}) secara permanen.`,
          confirmLabel: "Hapus Job",
          confirmColor: "#dc2626",
        }
      : action.kind === "refund"
      ? {
          title: "Refund Escrow ke Pemberi Kerja",
          description: `Dana escrow job "${action.posisi}" (ID: ${action.jobId}) akan dikembalikan ke pemberi kerja.`,
          confirmLabel: "Proses Refund",
          confirmColor: "#2563eb",
        }
      : {
          title: "Force Payout ke Pekerja",
          description: `100% upah dari job "${action.posisi}" (ID: ${action.jobId}) akan langsung dicairkan ke pekerja.`,
          confirmLabel: "Force Payout",
          confirmColor: "#059669",
        }
    : null;

  return (
    <div className="space-y-4">
      {toast && (
        <div className="fixed top-4 right-4 z-50 bg-gray-900 text-white text-sm font-semibold px-4 py-3 rounded-xl shadow-xl">
          {toast}
        </div>
      )}

      {action && modalMeta && (
        <ConfirmModal
          {...modalMeta}
          onConfirm={handleConfirm}
          onClose={() => setAction(null)}
          busy={busy}
        />
      )}

      <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden shadow-sm">
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-gray-100">
          <h3 className="font-black text-gray-900 flex items-center gap-2">
            <Briefcase className="w-4 h-4 text-emerald-700" /> Semua Job Posting ({rows.length})
          </h3>
          <button
            onClick={() => void load()}
            className="flex items-center gap-1.5 text-xs font-bold text-emerald-700 hover:text-emerald-900"
          >
            <RefreshCw className="w-3.5 h-3.5" /> Segarkan
          </button>
        </div>

        {loading ? (
          <div className="py-16 flex justify-center"><Loader2 className="w-6 h-6 animate-spin text-emerald-600" /></div>
        ) : rows.length === 0 ? (
          <div className="py-16 text-center text-sm text-gray-400">Belum ada job posting.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-gray-50 text-left text-[11px] uppercase tracking-wide text-gray-500">
                  <th className="px-4 py-2.5 font-bold">ID</th>
                  <th className="px-4 py-2.5 font-bold">Posisi</th>
                  <th className="px-4 py-2.5 font-bold">Perusahaan</th>
                  <th className="px-4 py-2.5 font-bold text-right">Escrow</th>
                  <th className="px-4 py-2.5 font-bold">Status</th>
                  <th className="px-4 py-2.5 font-bold text-right">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {rows.map((r) => (
                  <tr key={r.jobId} className="hover:bg-gray-50/60">
                    <td className="px-4 py-3 font-mono text-[11px] text-gray-500">{r.jobId}</td>
                    <td className="px-4 py-3">
                      <p className="font-semibold text-gray-900">{r.posisi}</p>
                      {r.hiringMode && (
                        <p className="text-[11px] text-gray-400 capitalize">{r.hiringMode}</p>
                      )}
                    </td>
                    <td className="px-4 py-3 text-gray-700">{r.employerName}</td>
                    <td className="px-4 py-3 text-right font-bold text-gray-800">{formatRp(r.escrowAmount)}</td>
                    <td className="px-4 py-3">{escrowStatusLabel(r.escrowStatus)}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1.5 justify-end flex-wrap">
                        <button
                          onClick={() => setAction({ jobId: r.jobId, posisi: r.posisi, kind: "delete" })}
                          className="inline-flex items-center gap-1 rounded-lg bg-red-600 text-white text-[11px] font-bold px-2 py-1.5 hover:bg-red-500"
                        >
                          <Trash2 className="w-3 h-3" /> Hapus
                        </button>
                        <button
                          onClick={() => setAction({ jobId: r.jobId, posisi: r.posisi, kind: "refund" })}
                          disabled={r.escrowStatus === "refunded" || r.escrowStatus === "released"}
                          className="inline-flex items-center gap-1 rounded-lg bg-blue-600 text-white text-[11px] font-bold px-2 py-1.5 hover:bg-blue-500 disabled:opacity-40 disabled:cursor-not-allowed"
                        >
                          <RotateCcw className="w-3 h-3" /> Refund
                        </button>
                        <button
                          onClick={() => setAction({ jobId: r.jobId, posisi: r.posisi, kind: "payout" })}
                          disabled={r.escrowStatus === "released"}
                          className="inline-flex items-center gap-1 rounded-lg bg-emerald-700 text-white text-[11px] font-bold px-2 py-1.5 hover:bg-emerald-600 disabled:opacity-40 disabled:cursor-not-allowed"
                        >
                          <Zap className="w-3 h-3" /> Force Payout
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

// ── Tab: Audit Logs ───────────────────────────────────────────────
function LogsTab() {
  const [logs, setLogs] = useState<AdminLogRow[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    try {
      setLogs(await fetchAdminLogs());
    } catch {
      /* keep last rows */
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void load(); }, [load]);

  const actionBadge = (action: string) => {
    const map: Record<string, { label: string; cls: string }> = {
      DELETE_JOB: { label: "Hapus Job", cls: "bg-red-100 text-red-700 border-red-200" },
      REFUND_JOB: { label: "Refund", cls: "bg-blue-100 text-blue-700 border-blue-200" },
      FORCE_PAYOUT_JOB: { label: "Force Payout", cls: "bg-emerald-100 text-emerald-700 border-emerald-200" },
    };
    const d = map[action] ?? { label: action, cls: "bg-gray-100 text-gray-600 border-gray-200" };
    return (
      <span className={`inline-block px-2 py-0.5 rounded-full text-[11px] font-bold border ${d.cls}`}>
        {d.label}
      </span>
    );
  };

  return (
    <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden shadow-sm">
      <div className="flex items-center justify-between px-5 py-3.5 border-b border-gray-100">
        <h3 className="font-black text-gray-900 flex items-center gap-2">
          <FileText className="w-4 h-4 text-emerald-700" /> Log Audit Admin
        </h3>
        <button
          onClick={() => void load()}
          className="flex items-center gap-1.5 text-xs font-bold text-emerald-700 hover:text-emerald-900"
        >
          <RefreshCw className="w-3.5 h-3.5" /> Segarkan
        </button>
      </div>

      {loading ? (
        <div className="py-16 flex justify-center"><Loader2 className="w-6 h-6 animate-spin text-emerald-600" /></div>
      ) : logs.length === 0 ? (
        <div className="py-16 text-center text-sm text-gray-400">Belum ada aktivitas admin tercatat.</div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-gray-50 text-left text-[11px] uppercase tracking-wide text-gray-500">
                <th className="px-4 py-2.5 font-bold">Waktu</th>
                <th className="px-4 py-2.5 font-bold">Admin</th>
                <th className="px-4 py-2.5 font-bold">Aksi</th>
                <th className="px-4 py-2.5 font-bold">Target ID</th>
                <th className="px-4 py-2.5 font-bold">Alasan</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {logs.map((l) => (
                <tr key={l.id} className="hover:bg-gray-50/60">
                  <td className="px-4 py-3 text-[11px] text-gray-500 whitespace-nowrap">
                    {new Date(l.createdAt).toLocaleString("id-ID", {
                      day: "2-digit", month: "short", year: "numeric",
                      hour: "2-digit", minute: "2-digit",
                    })}
                  </td>
                  <td className="px-4 py-3 font-mono text-[11px] text-gray-600">{l.adminId}</td>
                  <td className="px-4 py-3">{actionBadge(l.action)}</td>
                  <td className="px-4 py-3 font-mono text-[11px] text-gray-500">{l.targetId ?? "—"}</td>
                  <td className="px-4 py-3 text-sm text-gray-700 max-w-xs truncate" title={l.reason ?? ""}>
                    {l.reason ?? "—"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function SummaryCard({ label, value, tone }: { label: string; value: string; tone: "amber" | "gold" | "emerald" }) {
  const tones = {
    amber: "from-amber-500 to-amber-600",
    gold: "from-yellow-500 to-amber-500",
    emerald: "from-emerald-600 to-emerald-700",
  } as const;
  return (
    <div className={`rounded-2xl bg-gradient-to-br ${tones[tone]} p-4 text-white shadow-sm`}>
      <p className="text-[11px] font-semibold opacity-80">{label}</p>
      <p className="text-xl font-black mt-1">{value}</p>
    </div>
  );
}

// ── Command center shell ──────────────────────────────────────────
function CommandCenter({
  onLogout,
  trainingPassed,
  requireAcademy,
  onTrainingPassed,
}: {
  onLogout: () => void;
  trainingPassed: boolean;
  requireAcademy: boolean;
  onTrainingPassed: () => void;
}) {
  const [tab, setTab] = useState<Tab>("dashboard");
  const tabs: { id: Tab; label: string; icon: React.ReactNode }[] = [
    { id: "dashboard", label: "Dashboard Live", icon: <LayoutDashboard className="w-4 h-4" /> },
    { id: "revenue", label: "Analitik Pendapatan", icon: <LineChartIcon className="w-4 h-4" /> },
    { id: "escrow", label: "Pengawasan Escrow", icon: <Wallet className="w-4 h-4" /> },
    { id: "manual_finance", label: "Pembayaran Manual", icon: <Banknote className="w-4 h-4" /> },
    { id: "jobs", label: "Manajemen Job", icon: <Briefcase className="w-4 h-4" /> },
    { id: "resolution", label: "Pusat Resolusi", icon: <Gavel className="w-4 h-4" /> },
    { id: "onsite", label: "Monitoring Proyek Fisik", icon: <HardHat className="w-4 h-4" /> },
    { id: "users", label: "Pengguna & Blacklist", icon: <Users className="w-4 h-4" /> },
    { id: "kyc", label: "Verifikasi KYC", icon: <IdCard className="w-4 h-4" /> },
    { id: "academy", label: "Kurasi Akademi", icon: <GraduationCap className="w-4 h-4" /> },
    { id: "logs", label: "Log Audit", icon: <FileText className="w-4 h-4" /> },
    { id: "akun", label: "Pengaturan Akun", icon: <Settings2 className="w-4 h-4" /> },
  ];

  return (
    <div className="admin-portal-shell min-h-[100dvh] bg-[#f3f6f2] flex flex-col md:flex-row">
      {/* Sidebar */}
      <aside
        className="z-20 shrink-0 text-white md:sticky md:top-0 md:flex md:h-[100dvh] md:w-[258px] md:flex-col"
        style={{ background: "linear-gradient(180deg, #153c2e 0%, #103326 100%)" }}
      >
        <div className="px-5 py-4 flex items-center gap-3 border-b border-white/10">
          <div
            className="w-10 h-10 rounded-xl flex items-center justify-center shadow-sm"
            style={{ background: "#e4bd62" }}
          >
            <Shield className="w-5 h-5 text-emerald-950" strokeWidth={2.5} />
          </div>
          <div>
            <p className="font-extrabold text-sm leading-tight tracking-tight">Tilu Saudara Solusindo</p>
            <p className="text-[10px] uppercase tracking-[0.14em] text-[#dfbd70]">Command Center</p>
          </div>
        </div>

        {/* Training status pill */}
        <div className="px-4 pt-3 pb-1 md:pb-3">
          {trainingPassed ? (
            <div
              data-testid="training-status-passed"
              className="flex items-center gap-1.5 rounded-lg bg-emerald-800/60 border border-emerald-600/40 px-2.5 py-1.5"
            >
              <Award className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span className="text-[11px] font-bold text-emerald-100">Pelatihan Lulus</span>
            </div>
          ) : (
            <button
              data-testid="training-status-pending"
              onClick={() => setTab("academy")}
              className="w-full flex items-center gap-1.5 rounded-lg bg-amber-500/20 border border-amber-500/40 px-2.5 py-1.5 hover:bg-amber-500/30 transition-colors text-left"
            >
              <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span className="text-[11px] font-bold text-amber-300">Pelatihan belum lulus</span>
            </button>
          )}
        </div>

        <nav aria-label="Navigasi admin" className="flex gap-1.5 overflow-x-auto px-3 py-2 md:min-h-0 md:flex-1 md:flex-col md:overflow-x-hidden md:overflow-y-auto md:py-3">
          {tabs.map((t) => (
            <button
              key={t.id}
              data-testid={`tab-${t.id}`}
              onClick={() => setTab(t.id)}
              aria-current={tab === t.id ? "page" : undefined}
              className={`flex shrink-0 items-center gap-2.5 rounded-lg px-3 py-2.5 text-[12px] font-semibold whitespace-nowrap transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#e4bd62] focus-visible:ring-offset-2 focus-visible:ring-offset-[#153c2e] md:w-full ${
                tab === t.id ? "bg-white/[0.12] text-white" : "text-[#c2d4ca] hover:bg-white/[0.07] hover:text-white"
              }`}
              style={tab === t.id ? { boxShadow: `inset 3px 0 0 ${GOLD}` } : {}}
            >
              {t.icon} <span>{t.label}</span>
            </button>
          ))}
        </nav>
        <div className="px-3 pb-3 md:hidden">
          <button
            data-testid="button-admin-logout-mobile"
            onClick={onLogout}
            className="flex w-full items-center justify-center gap-2 rounded-lg border border-white/15 px-3 py-2.5 text-xs font-semibold text-[#c2d4ca] transition-colors hover:bg-white/[0.07] hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#e4bd62]"
          >
            <LogOut className="h-4 w-4" /> Keluar
          </button>
        </div>
        <div className="hidden p-3 md:block md:border-t md:border-white/10">
          <button
            data-testid="button-admin-logout"
            onClick={onLogout}
            className="flex w-full items-center gap-2 rounded-lg px-3 py-2.5 text-xs font-semibold text-[#c2d4ca] transition-colors hover:bg-white/[0.07] hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#e4bd62]"
          >
            <LogOut className="w-4 h-4" /> Keluar
          </button>
        </div>
      </aside>

      {/* Main */}
      <main className="min-w-0 flex-1 overflow-x-hidden p-4 sm:p-6 lg:p-8">
        <header className="mb-6 flex flex-wrap items-center justify-between gap-3 border-b border-[#dfe7e2] pb-5">
          <div>
            <div className="mb-1 text-[10px] font-bold uppercase tracking-[0.16em] text-[#718078]">Rekhastha · Operations</div>
            <h2 className="text-xl font-extrabold tracking-tight text-[#183c2e]">
              {tabs.find((t) => t.id === tab)?.label}
            </h2>
            <p className="mt-1 text-xs text-[#7d8c83]">Panel operator platform Rekhastha</p>
          </div>
          <div className="flex items-center gap-2 rounded-full border border-[#d8e4db] bg-[#fffefa] px-3 py-1.5 text-[10px] font-semibold uppercase tracking-[0.11em] text-[#4d775e]">
            <span className="h-1.5 w-1.5 rounded-full bg-[#49a477]" /> Control center
          </div>
        </header>
        {tab === "dashboard" && <DashboardTab />}
        {tab === "revenue" && <RevenueTab />}
        {tab === "escrow" && <EscrowTab trainingPassed={trainingPassed} requireAcademy={requireAcademy} />}
        {tab === "manual_finance" && <ManualFinanceAdminTab />}
        {tab === "jobs" && <JobsTab />}
        {tab === "resolution" && <ResolutionTab />}
        {tab === "onsite" && <OnsiteTab />}
        {tab === "users" && <UsersTab />}
        {tab === "kyc" && <KycTab />}
        {tab === "academy" && <AcademyTab onTrainingPassed={onTrainingPassed} />}
        {tab === "logs" && <LogsTab />}
        {tab === "akun" && <ChangePasswordTab />}
      </main>

      {/* Full-screen worker SOS alarm — blocks everything when active */}
      <EmergencyAlarm />
    </div>
  );
}

export default function AdminPortal() {
  const [authed, setAuthed] = useState<boolean | null>(null);
  const [trainingPassed, setTrainingPassed] = useState(false);
  const [requireAcademy, setRequireAcademy] = useState(false);
  const checked = useRef(false);

  const checkSession = async () => {
    try {
      const me = await adminMe();
      setTrainingPassed(me.trainingPassed);
      setRequireAcademy(me.requireAcademy);
      setAuthed(true);
    } catch {
      setAuthed(false);
    }
  };

  useEffect(() => {
    if (checked.current) return;
    checked.current = true;
    void checkSession();
  }, []);

  const handleLogout = async () => {
    try { await adminLogout(); } catch { /* ignore */ }
    setAuthed(false);
  };

  const handleLoginSuccess = async () => {
    await checkSession();
  };

  if (authed === null) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-emerald-950">
        <Loader2 className="w-7 h-7 animate-spin text-amber-400" />
      </div>
    );
  }

  return authed
    ? (
      <CommandCenter
        onLogout={handleLogout}
        trainingPassed={trainingPassed}
        requireAcademy={requireAcademy}
        onTrainingPassed={() => void checkSession()}
      />
    )
    : <LoginGate onSuccess={() => void handleLoginSuccess()} />;
}
