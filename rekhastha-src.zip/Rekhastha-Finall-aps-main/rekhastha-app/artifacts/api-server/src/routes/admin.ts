import { Router, type IRouter, type Request } from "express";
import { and, desc, eq, ilike, inArray, lte, or, sql } from "drizzle-orm";
import { z } from "zod/v4";
import {
  db,
  gigsTable,
  usersTable,
  attendanceTable,
  ratingsTable,
  academyCompletionsTable,
  academyQuestionsTable,
  adminLogsTable,
  instantOrdersTable,
  companySubscriptionsTable,
  applicationsTable,
  manualPaymentsTable,
} from "@workspace/db";
import {
  ADMIN_COOKIE,
  adminCookieOptions,
  adminSessionId,
  changeAdminPassword,
  createAdminSession,
  deleteAdminSession,
  isAdminSession,
  lockoutRemaining,
  pruneAdminState,
  recordFailedAttempt,
  resetAdminPassword,
  resetAttempts,
  verifyAdminPassword,
} from "../lib/admin";
import {
  getAllQuestionsForAdmin,
  getPassingScore,
  scoreQuiz,
  setPassingScore,
  toClientQuestions,
} from "../lib/academy";
import { broadcastGig } from "../lib/realtime";
import {
  INSTANT_PRICE_BY_CATEGORY,
  SUBSCRIPTION_PRICE_MONTHLY,
  calculateTotalWorkerPayout,
  getAdminFeeAmount,
  hasAdminFeeWaiverAt,
} from "../lib/pricing";
import { forcePayoutGig } from "../lib/admin-finance";

const router: IRouter = Router();

function clientIp(req: Request): string {
  const fwd = req.headers["x-forwarded-for"];
  if (typeof fwd === "string" && fwd) return fwd.split(",")[0].trim();
  return req.ip ?? "unknown";
}

function requireAdmin(req: Request): Promise<boolean> {
  return isAdminSession(req.cookies?.[ADMIN_COOKIE]);
}

// ── Auth ─────────────────────────────────────────────────────────
const loginBody = z.object({
  adminId: z.string().min(1),
  token: z.string().min(1),
});

router.post("/admin/login", async (req, res): Promise<void> => {
  const ip = clientIp(req);
  await pruneAdminState();
  const remaining = await lockoutRemaining(ip);
  if (remaining > 0) {
    res.status(429).json({
      error: `Terlalu banyak percobaan. Coba lagi dalam ${Math.ceil(remaining / 1000)} detik.`,
    });
    return;
  }

  const parsed = loginBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Identitas Admin dan Kata Sandi wajib diisi." });
    return;
  }

  const valid = await verifyAdminPassword(parsed.data.adminId.trim(), parsed.data.token);
  if (!valid) {
    await recordFailedAttempt(ip);
    req.log.warn({ ip }, "Failed admin login attempt");
    res.status(401).json({ error: "Identitas Admin atau Kata Sandi salah." });
    return;
  }

  await resetAttempts(ip);
  const session = await createAdminSession(
    parsed.data.adminId.trim(),
    req.cookies?.[ADMIN_COOKIE],
  );
  res.cookie(ADMIN_COOKIE, session, adminCookieOptions());
  res.json({ ok: true });
});

const changePasswordBody = z.object({
  oldPassword: z.string().min(1),
  newPassword: z.string().min(8, "Kata sandi minimal 8 karakter."),
});

router.post("/admin/change-password", async (req, res): Promise<void> => {
  const adminId = await adminSessionId(req.cookies?.[ADMIN_COOKIE]);
  if (!adminId) {
    res.status(401).json({ error: "Sesi admin tidak valid." });
    return;
  }

  const parsed = changePasswordBody.safeParse(req.body);
  if (!parsed.success) {
    const msg = parsed.error.issues[0]?.message ?? "Input tidak valid.";
    res.status(400).json({ error: msg });
    return;
  }

  const result = await changeAdminPassword(
    adminId,
    parsed.data.oldPassword,
    parsed.data.newPassword,
    req.cookies?.[ADMIN_COOKIE],
  );
  if ("error" in result) {
    res.status(400).json(result);
    return;
  }
  res.json(result);
});

const resetPasswordBody = z.object({
  newPassword: z.string().min(8, "Kata sandi minimal 8 karakter."),
  recoveryToken: z.string().min(1),
});

router.post("/admin/reset-password", async (req, res): Promise<void> => {
  const ip = clientIp(req);
  await pruneAdminState();
  const remaining = await lockoutRemaining(ip);
  if (remaining > 0) {
    res.status(429).json({
      error: `Terlalu banyak percobaan. Coba lagi dalam ${Math.ceil(remaining / 1000)} detik.`,
    });
    return;
  }

  const parsed = resetPasswordBody.safeParse(req.body);
  if (!parsed.success) {
    const msg = parsed.error.issues[0]?.message ?? "Input tidak valid.";
    res.status(400).json({ error: msg });
    return;
  }

  const result = await resetAdminPassword(parsed.data.newPassword, parsed.data.recoveryToken);
  if ("error" in result) {
    await recordFailedAttempt(ip);
    req.log.warn({ ip }, "Failed admin credential recovery attempt");
    res.status(400).json(result);
    return;
  }

  await resetAttempts(ip);
  req.log.info({ ip, adminId: result.adminId }, "Admin credentials recovered and rotated");
  res.json(result);
});

router.post("/admin/logout", async (req, res): Promise<void> => {
  await deleteAdminSession(req.cookies?.[ADMIN_COOKIE]);
  res.clearCookie(ADMIN_COOKIE, { path: "/" });
  res.status(204).end();
});

router.get("/admin/me", async (req, res): Promise<void> => {
  const adminId = await adminSessionId(req.cookies?.[ADMIN_COOKIE]);
  if (!adminId) {
    res.status(401).json({ error: "Sesi admin tidak valid." });
    return;
  }

  const passed = await db
    .select({ id: academyCompletionsTable.id })
    .from(academyCompletionsTable)
    .where(
      and(
        eq(academyCompletionsTable.adminId, adminId),
        eq(academyCompletionsTable.passed, true),
      ),
    )
    .limit(1);

  res.json({ ok: true, trainingPassed: passed.length > 0, requireAcademy });
});

// ── Escrow ledger ────────────────────────────────────────────────
router.get("/admin/ledger", async (req, res): Promise<void> => {
  if (!(await requireAdmin(req))) {
    res.status(401).json({ error: "Sesi admin tidak valid." });
    return;
  }

  const gigs = await db.select().from(gigsTable).orderBy(desc(gigsTable.postedAt));
  const gigIds = gigs.map((g) => g.id);

  const attendance = gigIds.length
    ? await db
        .select()
        .from(attendanceTable)
        .where(inArray(attendanceTable.jobId, gigIds))
    : [];
  const acceptedApplications = gigIds.length
    ? await db
        .select()
        .from(applicationsTable)
        .where(
          and(
            inArray(applicationsTable.jobId, gigIds),
            inArray(applicationsTable.status, ["diterima", "selesai"]),
          ),
        )
    : [];

  const workerByJob = new Map<number, { name: string; working: boolean; done: boolean }>();
  for (const application of acceptedApplications) {
    const cur = workerByJob.get(application.jobId) ?? { name: "", working: false, done: false };
    cur.name = cur.name ? `${cur.name}, ${application.workerName}` : application.workerName;
    workerByJob.set(application.jobId, cur);
  }
  for (const a of attendance) {
    const cur = workerByJob.get(a.jobId) ?? { name: a.workerName, working: false, done: false };
    if (!cur.name) cur.name = a.workerName;
    if (a.kind === "masuk") cur.working = true;
    if (a.kind === "pulang") cur.done = true;
    workerByJob.set(a.jobId, cur);
  }

  const rows = gigs.map((g) => {
    const workerNet = g.totalWorkerPayout;
    const platformCut = g.adminFeeAmount;
    const hasFinancialSnapshot = workerNet !== null && platformCut !== null;
    const att = workerByJob.get(g.id);

    let status: "deposited" | "working" | "released";
    if (g.escrowStatus === "released") status = "released";
    else if (att?.working) status = "working";
    else status = "deposited";

    return {
      jobId: g.id,
      posisi: g.posisi,
      employerName: g.employerName ?? g.namaPerusahaan ?? "—",
      workerName: att?.name ?? "—",
      totalUpah: workerNet,
      komisiPlatform: platformCut,
      totalSetoran: hasFinancialSnapshot ? workerNet + platformCut : null,
      snapshotMissing: !hasFinancialSnapshot,
      escrowStatus: g.escrowStatus ?? "locked",
      paymentStatus: g.paymentStatus,
      payoutEligible:
        g.paymentStatus === "confirmed" &&
        g.totalWorkerPayout !== null &&
        ["pending", "processing", "locked"].includes(g.escrowStatus ?? "") &&
        acceptedApplications.filter((application) => application.jobId === g.id).length === Math.max(1, g.kuota ?? 1),
      status,
      postedAt: g.postedAt,
    };
  });

  res.json(rows);
});

router.get("/admin/fee-migration/status", async (req, res): Promise<void> => {
  if (!(await requireAdmin(req))) {
    res.status(401).json({ error: "Sesi admin tidak valid." });
    return;
  }
  const [gigs, migrationRun] = await Promise.all([
    db.select().from(gigsTable),
    db
      .select({ id: adminLogsTable.id })
      .from(adminLogsTable)
      .where(eq(adminLogsTable.action, "MIGRATE_HISTORICAL_JOB_FEES"))
      .limit(1),
  ]);
  const employerIds = [...new Set(gigs.map((gig) => gig.employerId).filter((id): id is string => !!id))];
  const [employers, subscriptions] = employerIds.length
    ? await Promise.all([
        db.select().from(usersTable).where(inArray(usersTable.id, employerIds)),
        db.select().from(companySubscriptionsTable).where(inArray(companySubscriptionsTable.companyId, employerIds)),
      ])
    : [[], []];
  const employerById = new Map(employers.map((employer) => [employer.id, employer]));
  const subscriptionById = new Map(subscriptions.map((subscription) => [subscription.companyId, subscription]));
  let pending = 0;
  let needsReview = 0;

  for (const gig of gigs) {
    const employer = gig.employerId ? employerById.get(gig.employerId) : undefined;
    const subscription = gig.employerId ? subscriptionById.get(gig.employerId) : undefined;
    const totalWorkerPayout = calculateTotalWorkerPayout(
      gig.nominal,
      gig.pembayaran,
      gig.jumlahHari,
      gig.kuota,
    );
    const adminFeeAmount = hasAdminFeeWaiverAt(gig.postedAt, employer, subscription)
      ? 0
      : getAdminFeeAmount(gig.jobCategory ?? gig.posisi);
    if (!Number.isSafeInteger(totalWorkerPayout) || totalWorkerPayout <= 0) {
      if (gig.totalWorkerPayout !== totalWorkerPayout || gig.adminFeeAmount !== adminFeeAmount || gig.feeRate !== 0) {
        pending += 1;
        needsReview += 1;
      }
      continue;
    }
    if (
      gig.totalWorkerPayout !== totalWorkerPayout ||
      gig.adminFeeAmount !== adminFeeAmount ||
      gig.feeRate !== 0
    ) {
      pending += 1;
    }
  }
  res.json({ pending, needsReview, complete: migrationRun.length > 0 });
});

router.post("/admin/fee-migration/run", async (req, res): Promise<void> => {
  const adminId = await adminSessionId(req.cookies?.[ADMIN_COOKIE]);
  if (!adminId) {
    res.status(401).json({ error: "Sesi admin tidak valid." });
    return;
  }

  const result = await db.transaction(async (tx) => {
    await tx.execute(sql`SELECT pg_advisory_xact_lock(27803926)`);
    const [migrationRun] = await tx
      .select({ id: adminLogsTable.id })
      .from(adminLogsTable)
      .where(eq(adminLogsTable.action, "MIGRATE_HISTORICAL_JOB_FEES"))
      .limit(1);
    if (migrationRun) return { alreadyRun: true as const };

    const gigs = await tx.select().from(gigsTable).for("update");
    const employerIds = [...new Set(gigs.map((row) => row.employerId).filter((id): id is string => !!id))];
    const [employers, subscriptions] = employerIds.length
      ? await Promise.all([
          tx.select().from(usersTable).where(inArray(usersTable.id, employerIds)),
          tx.select().from(companySubscriptionsTable).where(inArray(companySubscriptionsTable.companyId, employerIds)),
        ])
      : [[], []];
    const employerById = new Map(employers.map((user) => [user.id, user]));
    const subscriptionById = new Map(subscriptions.map((subscription) => [subscription.companyId, subscription]));
    let migrated = 0;
    let remaining = 0;

    for (const gig of gigs) {
      const postedAt = gig.postedAt;
      const employer = gig.employerId ? employerById.get(gig.employerId) : undefined;
      const subscription = gig.employerId ? subscriptionById.get(gig.employerId) : undefined;
      const totalWorkerPayout = calculateTotalWorkerPayout(
        gig.nominal,
        gig.pembayaran,
        gig.jumlahHari,
        gig.kuota,
      );
      const adminFeeAmount = hasAdminFeeWaiverAt(postedAt, employer, subscription)
        ? 0
        : getAdminFeeAmount(gig.jobCategory ?? gig.posisi);
      if (
        totalWorkerPayout <= 0 ||
        !Number.isSafeInteger(totalWorkerPayout) ||
        !Number.isSafeInteger(totalWorkerPayout + adminFeeAmount)
      ) {
        if (
          gig.totalWorkerPayout !== totalWorkerPayout ||
          gig.adminFeeAmount !== adminFeeAmount ||
          gig.feeRate !== 0
        ) remaining += 1;
        continue;
      }
      if (
        gig.totalWorkerPayout === totalWorkerPayout &&
        gig.adminFeeAmount === adminFeeAmount &&
        gig.feeRate === 0
      ) continue;

      await tx
        .update(gigsTable)
        .set({ totalWorkerPayout, adminFeeAmount, feeRate: 0 })
        .where(eq(gigsTable.id, gig.id));

      // Only unpaid/rejected obligations may be repriced. Submitted and
      // confirmed transfers remain untouched as historical financial evidence.
      if (gig.paymentStatus !== "confirmed" && gig.employerId) {
        await tx
          .update(manualPaymentsTable)
          .set({ amount: totalWorkerPayout + adminFeeAmount })
          .where(
            and(
              eq(manualPaymentsTable.targetType, "gig_escrow"),
              eq(manualPaymentsTable.targetId, String(gig.id)),
              inArray(manualPaymentsTable.status, ["awaiting_payment", "rejected"]),
            ),
          );
      }
      migrated += 1;
    }
    await tx.insert(adminLogsTable).values({
      adminId,
      action: "MIGRATE_HISTORICAL_JOB_FEES",
      targetId: "all",
      reason: `Snapshotted flat admin fees and worker payouts for ${migrated} jobs; ${remaining} need review. No historical transfer or wallet balance was changed.`,
    });
    return { alreadyRun: false as const, migrated, remaining };
  });

  if (result.alreadyRun) {
    res.status(409).json({ error: "Migrasi snapshot biaya sudah pernah dijalankan." });
    return;
  }
  req.log.info({ adminId, ...result }, "Admin migrated historical job fee snapshots");
  res.json({ ok: true, ...result, complete: true });
});

const forceReleaseBody = z.object({
  jobId: z.coerce.number(),
});

/**
 * When REQUIRE_ACADEMY=true the force-release endpoint is hard-gated behind a
 * passed operator assessment. Set the env var in production; leave it unset (or
 * set to anything other than "true") in dev so new operators aren't locked out
 * before they've had a chance to take the quiz.
 */
const requireAcademy = process.env["REQUIRE_ACADEMY"] === "true";

router.post("/admin/force-release", async (req, res): Promise<void> => {
  const adminId = await adminSessionId(req.cookies?.[ADMIN_COOKIE]);
  if (!adminId) {
    res.status(401).json({ error: "Sesi admin tidak valid." });
    return;
  }

  if (requireAcademy) {
    const passed = await db
      .select({ id: academyCompletionsTable.id })
      .from(academyCompletionsTable)
      .where(
        and(
          eq(academyCompletionsTable.adminId, adminId),
          eq(academyCompletionsTable.passed, true),
        ),
      )
      .limit(1);

    if (passed.length === 0) {
      req.log.warn({ adminId }, "Force-release blocked — operator has not passed academy");
      res.status(403).json({
        error: "Aksi ini membutuhkan kelulusan Akademi Operator. Selesaikan asesmen di tab Akademi terlebih dahulu.",
      });
      return;
    }
  }

  const parsed = forceReleaseBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "jobId tidak valid." });
    return;
  }

  const result = await forcePayoutGig(
    parsed.data.jobId,
    adminId,
    "Force-release melalui Pusat Resolusi",
  );
  if (!result.ok) {
    const status = result.error === "not_found" ? 404 : 409;
    res.status(status).json({ error: result.error });
    return;
  }
  req.log.info(
    { jobId: result.gig.id, adminId, amount: result.amount, credited: result.credited, duplicate: result.duplicate },
    "Admin force-release credited worker wallet",
  );
  res.json({ ok: true, amount: result.amount, credited: result.credited, duplicate: result.duplicate });
});

// ── User management ──────────────────────────────────────────────
const adminUsersQuerySchema = z.object({
  page: z.coerce.number().int().min(1).default(1),
  limit: z.coerce.number().int().min(1).max(200).default(50),
  q: z.string().max(100).optional(),
});

router.get("/admin/users", async (req, res): Promise<void> => {
  if (!(await requireAdmin(req))) {
    res.status(401).json({ error: "Sesi admin tidak valid." });
    return;
  }

  const parsed = adminUsersQuerySchema.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: "Parameter tidak valid." });
    return;
  }

  const { page, limit, q } = parsed.data;
  const offset = (page - 1) * limit;

  // Filter opsional berdasarkan nama atau email
  const searchFilter = q
    ? or(ilike(usersTable.name, `%${q}%`), ilike(usersTable.email, `%${q}%`))
    : undefined;

  const [users, [{ total }]] = await Promise.all([
    db
      .select()
      .from(usersTable)
      .where(searchFilter)
      .orderBy(desc(usersTable.createdAt))
      .limit(limit)
      .offset(offset),
    db
      .select({ total: sql<number>`count(*)::int` })
      .from(usersTable)
      .where(searchFilter),
  ]);

  const negativeRatings = await db
    .select()
    .from(ratingsTable)
    .where(lte(ratingsTable.score, 2));

  const negByName = new Map<string, number>();
  for (const r of negativeRatings) {
    negByName.set(r.targetName, (negByName.get(r.targetName) ?? 0) + 1);
  }

  const rows = users.map((u) => {
    const profile = (u.profile ?? {}) as Record<string, unknown>;
    const companyName = typeof profile["namaPerusahaan"] === "string"
      ? (profile["namaPerusahaan"] as string)
      : undefined;
    const displayName = companyName || u.name;
    const negativeCount =
      (negByName.get(u.name) ?? 0) + (companyName ? negByName.get(companyName) ?? 0 : 0);

    return {
      id: u.id,
      name: u.name,
      displayName,
      email: u.email,
      role: u.role,
      suspended: u.suspended,
      negativeRatings: negativeCount,
      createdAt: u.createdAt,
    };
  });

  res.json({
    data: rows,
    pagination: {
      page,
      limit,
      total,
      totalPages: Math.ceil(total / limit),
    },
  });
});

const suspendBody = z.object({
  userId: z.string().min(1),
  suspended: z.boolean(),
});

router.post("/admin/users/suspend", async (req, res): Promise<void> => {
  if (!(await requireAdmin(req))) {
    res.status(401).json({ error: "Sesi admin tidak valid." });
    return;
  }
  const parsed = suspendBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Permintaan tidak valid." });
    return;
  }

  const [user] = await db
    .update(usersTable)
    .set({ suspended: parsed.data.suspended })
    .where(eq(usersTable.id, parsed.data.userId))
    .returning();

  if (!user) {
    res.status(404).json({ error: "Pengguna tidak ditemukan." });
    return;
  }

  req.log.info(
    { userId: user.id, suspended: user.suspended },
    "Admin toggled user suspension",
  );
  res.json({ id: user.id, suspended: user.suspended });
});

// ── KYC verification queue ────────────────────────────────────────

/**
 * List workers who have submitted at least one KYC document, most recently
 * submitted first (using createdAt as a stable proxy — there's no separate
 * submittedAt column). Used to populate the admin moderation queue.
 */
router.get("/admin/kyc", async (req, res): Promise<void> => {
  if (!(await requireAdmin(req))) {
    res.status(401).json({ error: "Sesi admin tidak valid." });
    return;
  }

  const users = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.role, "pekerja"))
    .orderBy(desc(usersTable.createdAt));

  const rows = users
    .filter((u) => u.ktpPhotoUrl || u.selfieWithKtpUrl)
    .map((u) => ({
      id: u.id,
      name: u.name,
      email: u.email,
      ktpPhotoUrl: u.ktpPhotoUrl,
      selfieWithKtpUrl: u.selfieWithKtpUrl,
      verificationStatus: u.verificationStatus,
    }));

  res.json(rows);
});

const kycVerifyBody = z.object({
  userId: z.string().min(1),
  status: z.enum(["verified", "rejected", "pending"]),
});

/** Approve/reject a worker's KYC submission. Every decision is audit-logged. */
router.post("/admin/kyc/verify", async (req, res): Promise<void> => {
  const adminId = await adminSessionId(req.cookies?.[ADMIN_COOKIE]);
  if (!adminId) {
    res.status(401).json({ error: "Sesi admin tidak valid." });
    return;
  }

  const parsed = kycVerifyBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Permintaan tidak valid." });
    return;
  }

  const [user] = await db
    .update(usersTable)
    .set({ verificationStatus: parsed.data.status })
    .where(eq(usersTable.id, parsed.data.userId))
    .returning();

  if (!user) {
    res.status(404).json({ error: "Pengguna tidak ditemukan." });
    return;
  }

  await db.insert(adminLogsTable).values({
    adminId,
    action: `KYC_${parsed.data.status.toUpperCase()}`,
    targetId: user.id,
    reason: null,
  });

  req.log.info(
    { adminId, userId: user.id, status: parsed.data.status },
    "Admin reviewed KYC submission",
  );
  res.json({ id: user.id, verificationStatus: user.verificationStatus });
});

// ── Academy (operator onboarding quiz) ───────────────────────────
router.get("/admin/academy", async (req, res): Promise<void> => {
  const adminId = await adminSessionId(req.cookies?.[ADMIN_COOKIE]);
  if (!adminId) {
    res.status(401).json({ error: "Sesi admin tidak valid." });
    return;
  }

  const [questions, passingScore, completions] = await Promise.all([
    toClientQuestions(),
    getPassingScore(),
    db
      .select()
      .from(academyCompletionsTable)
      .where(eq(academyCompletionsTable.adminId, adminId))
      .orderBy(desc(academyCompletionsTable.completedAt)),
  ]);

  res.json({
    passingScore,
    questions,
    completions: completions.map((c) => ({
      id: c.id,
      adminId: c.adminId,
      correct: c.correct,
      total: c.total,
      score: c.score,
      passed: c.passed,
      completedAt: c.completedAt,
    })),
  });
});

const academySubmitBody = z.object({
  answers: z
    .array(
      z.object({
        questionId: z.string().min(1),
        selectedIndex: z.number().int().min(0),
      }),
    )
    .min(1),
});

router.post("/admin/academy/submit", async (req, res): Promise<void> => {
  const adminId = await adminSessionId(req.cookies?.[ADMIN_COOKIE]);
  if (!adminId) {
    res.status(401).json({ error: "Sesi admin tidak valid." });
    return;
  }

  const parsed = academySubmitBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Jawaban kuis tidak valid." });
    return;
  }

  const result = await scoreQuiz(parsed.data.answers);

  const [saved] = await db
    .insert(academyCompletionsTable)
    .values({
      adminId,
      correct: result.correct,
      total: result.total,
      score: result.score,
      passed: result.passed,
      answers: result.answers,
    })
    .returning();

  req.log.info(
    { adminId, score: result.score, passed: result.passed },
    "Admin completed academy assessment",
  );

  const passingScore = await getPassingScore();

  res.json({
    id: saved.id,
    completedAt: saved.completedAt,
    passingScore,
    correct: result.correct,
    total: result.total,
    score: result.score,
    passed: result.passed,
    answers: result.answers,
  });
});

// ── Academy question editor (admin CRUD) ──────────────────────────

router.get("/admin/academy/questions", async (req, res): Promise<void> => {
  if (!(await requireAdmin(req))) {
    res.status(401).json({ error: "Sesi admin tidak valid." });
    return;
  }
  const rows = await getAllQuestionsForAdmin();
  res.json(
    rows.map((r) => ({
      id: r.id,
      slug: r.slug,
      category: r.category,
      prompt: r.prompt,
      options: r.options as string[],
      correctIndex: r.correctIndex,
      explanation: r.explanation,
      sortOrder: r.sortOrder,
    })),
  );
});

const questionBody = z.object({
  category: z.string().min(1),
  prompt: z.string().min(1),
  options: z.array(z.string().min(1)).min(2).max(8),
  correctIndex: z.number().int().min(0),
  explanation: z.string().default(""),
  sortOrder: z.number().int().default(0),
});

router.post("/admin/academy/questions", async (req, res): Promise<void> => {
  if (!(await requireAdmin(req))) {
    res.status(401).json({ error: "Sesi admin tidak valid." });
    return;
  }
  const parsed = questionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Data soal tidak valid.", detail: parsed.error.issues });
    return;
  }
  if (parsed.data.correctIndex >= parsed.data.options.length) {
    res.status(400).json({ error: "correctIndex melebihi jumlah opsi." });
    return;
  }

  const slug = `q-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;

  const [row] = await db
    .insert(academyQuestionsTable)
    .values({
      slug,
      category: parsed.data.category,
      prompt: parsed.data.prompt,
      options: parsed.data.options,
      correctIndex: parsed.data.correctIndex,
      explanation: parsed.data.explanation,
      sortOrder: parsed.data.sortOrder,
    })
    .returning();

  req.log.info({ id: row.id }, "Admin created academy question");
  res.status(201).json({
    id: row.id,
    slug: row.slug,
    category: row.category,
    prompt: row.prompt,
    options: row.options as string[],
    correctIndex: row.correctIndex,
    explanation: row.explanation,
    sortOrder: row.sortOrder,
  });
});

const questionUpdateBody = questionBody.extend({
  slug: z.string().optional(),
});

router.put("/admin/academy/questions/:id", async (req, res): Promise<void> => {
  if (!(await requireAdmin(req))) {
    res.status(401).json({ error: "Sesi admin tidak valid." });
    return;
  }
  const id = Number(req.params["id"]);
  if (!Number.isFinite(id)) {
    res.status(400).json({ error: "ID tidak valid." });
    return;
  }
  const parsed = questionUpdateBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Data soal tidak valid.", detail: parsed.error.issues });
    return;
  }
  if (parsed.data.correctIndex >= parsed.data.options.length) {
    res.status(400).json({ error: "correctIndex melebihi jumlah opsi." });
    return;
  }

  const [row] = await db
    .update(academyQuestionsTable)
    .set({
      category: parsed.data.category,
      prompt: parsed.data.prompt,
      options: parsed.data.options,
      correctIndex: parsed.data.correctIndex,
      explanation: parsed.data.explanation,
      sortOrder: parsed.data.sortOrder,
    })
    .where(eq(academyQuestionsTable.id, id))
    .returning();

  if (!row) {
    res.status(404).json({ error: "Soal tidak ditemukan." });
    return;
  }

  req.log.info({ id: row.id }, "Admin updated academy question");
  res.json({
    id: row.id,
    slug: row.slug,
    category: row.category,
    prompt: row.prompt,
    options: row.options as string[],
    correctIndex: row.correctIndex,
    explanation: row.explanation,
    sortOrder: row.sortOrder,
  });
});

router.delete("/admin/academy/questions/:id", async (req, res): Promise<void> => {
  if (!(await requireAdmin(req))) {
    res.status(401).json({ error: "Sesi admin tidak valid." });
    return;
  }
  const id = Number(req.params["id"]);
  if (!Number.isFinite(id)) {
    res.status(400).json({ error: "ID tidak valid." });
    return;
  }

  const [deleted] = await db
    .delete(academyQuestionsTable)
    .where(eq(academyQuestionsTable.id, id))
    .returning({ id: academyQuestionsTable.id });

  if (!deleted) {
    res.status(404).json({ error: "Soal tidak ditemukan." });
    return;
  }

  req.log.info({ id }, "Admin deleted academy question");
  res.json({ ok: true });
});

// ── Academy settings (passing score) ─────────────────────────────

router.get("/admin/academy/settings", async (req, res): Promise<void> => {
  if (!(await requireAdmin(req))) {
    res.status(401).json({ error: "Sesi admin tidak valid." });
    return;
  }
  const passingScore = await getPassingScore();
  res.json({ passingScore });
});

const settingsBody = z.object({
  passingScore: z.number().int().min(1).max(100),
});

router.put("/admin/academy/settings", async (req, res): Promise<void> => {
  if (!(await requireAdmin(req))) {
    res.status(401).json({ error: "Sesi admin tidak valid." });
    return;
  }
  const parsed = settingsBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Nilai tidak valid. Nilai lulus harus antara 1–100." });
    return;
  }
  await setPassingScore(parsed.data.passingScore);
  req.log.info({ passingScore: parsed.data.passingScore }, "Admin updated passing score");
  res.json({ passingScore: parsed.data.passingScore });
});

// ── Live platform stats ───────────────────────────────────────────
router.get("/admin/stats", async (req, res): Promise<void> => {
  if (!(await requireAdmin(req))) {
    res.status(401).json({ error: "Sesi admin tidak valid." });
    return;
  }
  const [allUsers, allGigs] = await Promise.all([
    db.select().from(usersTable),
    db.select().from(gigsTable),
  ]);
  const now = Date.now();
  const day = 86_400_000;
  const totalUsers = allUsers.length;
  const newUsersToday = allUsers.filter(
    (u) => u.createdAt && new Date(u.createdAt).getTime() > now - day,
  ).length;
  const workers = allUsers.filter((u) => u.role === "pekerja").length;
  const employers = allUsers.filter((u) => u.role === "perusahaan").length;
  const activeGigs = allGigs.filter((g) => g.escrowStatus === "locked").length;
  const releasedGigs = allGigs.filter((g) => g.escrowStatus === "released").length;
  const disputedGigs = allGigs.filter((g) => g.escrowStatus === "disputed").length;
  const totalGigs = allGigs.length;
  const escrowHeld = allGigs
    .filter((g) => g.escrowStatus === "locked")
    .reduce((s, g) => s + (g.escrowAmount ?? 0), 0);
  const escrowReleased = allGigs
    .filter((g) => g.escrowStatus === "released")
    .reduce((s, g) => s + (g.escrowAmount ?? 0), 0);
  const escrowDisputed = allGigs
    .filter((g) => g.escrowStatus === "disputed")
    .reduce((s, g) => s + (g.escrowAmount ?? 0), 0);
  res.json({
    totalUsers, newUsersToday, workers, employers,
    activeGigs, releasedGigs, disputedGigs, totalGigs,
    escrowHeld, escrowReleased, escrowDisputed,
  });
});

// ── Revenue analytics: flat job-posting fees + subscriptions ───────
function categoryForAmount(amount: number): string {
  for (const [category, price] of Object.entries(INSTANT_PRICE_BY_CATEGORY)) {
    if (price === amount) return category;
  }
  return "lainnya";
}

function categoryForPosting(gig: typeof gigsTable.$inferSelect | undefined, amount: number): string {
  const category = (gig?.jobCategory ?? "").trim().toLowerCase();
  if (category.includes("prof")) return "profesional";
  if (category.includes("terampil") || category.includes("teknis") || category.includes("technical")) return "terampil";
  if (category.includes("umum")) return "umum";
  return categoryForAmount(amount);
}

router.get("/admin/revenue", async (req, res): Promise<void> => {
  if (!(await requireAdmin(req))) {
    res.status(401).json({ error: "Sesi admin tidak valid." });
    return;
  }

  const [allOrders, allSubs, confirmedGigPayments, allGigs] = await Promise.all([
    db.select().from(instantOrdersTable),
    db.select().from(companySubscriptionsTable),
    db
      .select()
      .from(manualPaymentsTable)
      .where(
        and(
          eq(manualPaymentsTable.targetType, "gig_escrow"),
          eq(manualPaymentsTable.status, "confirmed"),
        ),
      ),
    db.select().from(gigsTable),
  ]);

  // Instant-order rows created by the new posting flow are matching records,
  // not separate charges. Count only gateway-era orders without a confirmed
  // manual gig payment, then recognize the flat-fee snapshot once per paid gig.
  const paidOrders = allOrders.filter(
    (o) => o.status === "active" || o.status === "completed",
  );
  const manuallyFundedGigIds = new Set(confirmedGigPayments.map((payment) => payment.targetId));
  const gigById = new Map(allGigs.map((gig) => [gig.id, gig]));
  const postingRevenueRows: { amount: number; category: string; at: Date | null }[] = [];

  for (const payment of confirmedGigPayments) {
    const gig = gigById.get(Number(payment.targetId));
    const fee = gig?.adminFeeAmount;
    if (!gig || fee == null || !Number.isSafeInteger(fee) || fee < 0) continue;
    postingRevenueRows.push({
      amount: fee,
      category: categoryForPosting(gig, fee),
      at: payment.reviewedAt ?? payment.createdAt,
    });
  }
  for (const order of paidOrders) {
    if (manuallyFundedGigIds.has(String(order.jobId))) continue;
    const gig = gigById.get(order.jobId);
    postingRevenueRows.push({
      amount: order.amount,
      category: categoryForPosting(gig, order.amount),
      at: order.createdAt,
    });
  }

  // A subscription row represents a paid Rp149.000/bulan purchase the moment
  // it was created — there is no separate payment ledger for renewals yet.
  const paidSubs = allSubs.filter((s) => s.isPremium);

  const now = Date.now();
  const day = 86_400_000;
  const startOfToday = new Date(now - (now % day));

  const postingRevenue = postingRevenueRows.reduce((sum, row) => sum + row.amount, 0);
  const subscriptionRevenue = paidSubs.length * SUBSCRIPTION_PRICE_MONTHLY;

  const byCategory: Record<string, { count: number; amount: number }> = {
    umum: { count: 0, amount: 0 },
    terampil: { count: 0, amount: 0 },
    profesional: { count: 0, amount: 0 },
    lainnya: { count: 0, amount: 0 },
  };
  for (const row of postingRevenueRows) {
    const cat = row.category in byCategory ? row.category : "lainnya";
    byCategory[cat].count += 1;
    byCategory[cat].amount += row.amount;
  }

  const todayRevenue =
    postingRevenueRows
      .filter((row) => row.at && new Date(row.at) >= startOfToday)
      .reduce((sum, row) => sum + row.amount, 0) +
    paidSubs
      .filter((s) => s.createdAt && new Date(s.createdAt) >= startOfToday)
      .length * SUBSCRIPTION_PRICE_MONTHLY;

  // Last 14 days, oldest first, for the trend chart.
  const DAYS = 14;
  const daily: { date: string; postings: number; subscription: number; total: number }[] = [];
  for (let i = DAYS - 1; i >= 0; i--) {
    const bucketStart = startOfToday.getTime() - i * day;
    const bucketEnd = bucketStart + day;
    const postings = postingRevenueRows
      .filter((row) => {
        const t = row.at ? new Date(row.at).getTime() : 0;
        return t >= bucketStart && t < bucketEnd;
      })
      .reduce((sum, row) => sum + row.amount, 0);
    const subscription =
      paidSubs.filter((s) => {
        const t = s.createdAt ? new Date(s.createdAt).getTime() : 0;
        return t >= bucketStart && t < bucketEnd;
      }).length * SUBSCRIPTION_PRICE_MONTHLY;
    daily.push({
      date: new Date(bucketStart).toISOString().slice(0, 10),
      postings,
      subscription,
      total: postings + subscription,
    });
  }

  res.json({
    totalRevenue: postingRevenue + subscriptionRevenue,
    postingRevenue,
    subscriptionRevenue,
    todayRevenue,
    activeSubscriptions: paidSubs.filter(
      (s) => !s.expiresAt || s.expiresAt.getTime() > now,
    ).length,
    totalPaidPostings: postingRevenueRows.length,
    byCategory,
    daily,
  });
});

export default router;
