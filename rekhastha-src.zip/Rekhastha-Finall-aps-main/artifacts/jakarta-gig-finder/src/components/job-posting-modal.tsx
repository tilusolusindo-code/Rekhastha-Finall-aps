import { useState, useEffect } from "react";
import { X, Plus, AlertTriangle, ShieldCheck, Building2, Users, Lock, ChevronLeft } from "lucide-react";
import {
  CustomJob, PaymentType, calcTotal, paymentLabels,
  DurasiKontrak, TipeAkun, durasiKontrakOptions, detectFraud,
} from "@/types/custom-job";
import { calcEscrowAmount, DURATION_DAYS, DEFAULT_FEE_RATE, calcSplit, calcEmployerDeposit, calcEmployerFee } from "@/types/escrow";

interface JobPostingModalProps {
  onSubmit: (job: Omit<CustomJob, "id" | "type" | "lat" | "lng" | "postedAt">) => void;
}

function formatRupiah(v: number) { return v ? "Rp " + v.toLocaleString("id-ID") : "Rp 0"; }

export default function JobPostingModal({ onSubmit }: JobPostingModalProps) {
  const [open, setOpen] = useState(false);

  // Form fields
  const [posisi, setPosisi] = useState("");
  const [deskripsi, setDeskripsi] = useState("");
  const [pembayaran, setPembayaran] = useState<PaymentType>("per_shift");
  const [nominal, setNominal] = useState("");
  const [dresscode, setDresscode] = useState("");
  const [kuota, setKuota] = useState("1");
  const [namaPerusahaan, setNamaPerusahaan] = useState("");
  const [nibPerusahaan, setNibPerusahaan] = useState("");
  const [durasiKontrak, setDurasiKontrak] = useState<DurasiKontrak>("harian");
  const [tipeAkun, setTipeAkun] = useState<TipeAkun>("perusahaan");
  const [kuotaMassal, setKuotaMassal] = useState("20");

  // Validation
  const [fraudWarning, setFraudWarning] = useState<string | null>(null);
  const [blocked, setBlocked] = useState(false);
  const [nibError, setNibError] = useState<string | null>(null);

  // Escrow confirmation step
  const [showEscrowConfirm, setShowEscrowConfirm] = useState(false);
  const [jumlahHari, setJumlahHari] = useState(1);

  const isAgency = tipeAkun === "agensi";
  const effectiveKuota = isAgency ? parseInt(kuotaMassal) || 1 : parseInt(kuota) || 1;
  const nominalNum = parseInt(nominal.replace(/\D/g, "")) || 0;

  const total = calcTotal(nominalNum, pembayaran);

  // Escrow calculations
  const escrowGross = calcEscrowAmount(nominalNum, pembayaran, jumlahHari, effectiveKuota);
  const escrowDeposit = calcEmployerDeposit(escrowGross);
  const escrowSplit = calcSplit(escrowDeposit);

  const handleNominalChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value.replace(/\D/g, "");
    setNominal(raw ? parseInt(raw).toLocaleString("id-ID") : "");
  };

  const handleDeskripsiChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const val = e.target.value;
    setDeskripsi(val);
    const kw = detectFraud(val);
    setFraudWarning(kw);
    setBlocked(!!kw);
  };

  const handleNibChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value.replace(/\D/g, "");
    setNibPerusahaan(val);
    setNibError(val.length > 0 && val.length < 13 ? "NIB harus 13 digit (sesuai OSS-RBA)" : null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!posisi.trim() || !deskripsi.trim() || !nominalNum || !dresscode.trim()) return;
    if (blocked || (nibPerusahaan.length > 0 && nibPerusahaan.length < 13)) return;
    // Show escrow confirmation step first
    setShowEscrowConfirm(true);
  };

  const handleEscrowConfirm = () => {
    onSubmit({
      posisi: posisi.trim(),
      deskripsi: deskripsi.trim(),
      pembayaran, nominal: nominalNum,
      dresscode: dresscode.trim(),
      kuota: effectiveKuota,
      durasiKontrak,
      nibPerusahaan: nibPerusahaan || undefined,
      namaPerusahaan: namaPerusahaan.trim() || undefined,
      tipeAkun,
      isAgency,
      escrowStatus: "locked",
      escrowAmount: escrowDeposit,
      jumlahHari,
    });

    // Reset
    setPosisi(""); setDeskripsi(""); setPembayaran("per_shift"); setNominal("");
    setDresscode(""); setKuota("1"); setNamaPerusahaan(""); setNibPerusahaan("");
    setDurasiKontrak("harian"); setTipeAkun("perusahaan"); setKuotaMassal("20");
    setFraudWarning(null); setBlocked(false); setNibError(null);
    setShowEscrowConfirm(false);
    setOpen(false);
  };

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [open]);

  // Sync jumlahHari default with duration
  useEffect(() => {
    setJumlahHari(DURATION_DAYS[durasiKontrak] ?? 1);
  }, [durasiKontrak]);

  return (
    <>
      <button
        data-testid="button-open-job-posting"
        onClick={() => setOpen(true)}
        className="fixed bottom-6 right-4 z-50 flex items-center gap-2 bg-primary text-white font-semibold px-5 py-3.5 rounded-full shadow-xl hover:bg-primary/90 active:scale-95 transition-all"
        style={{ boxShadow: "0 4px 20px rgba(6,95,70,0.45)" }}
      >
        <Plus className="w-5 h-5" />
        <span className="text-sm">Buka Lowongan Baru</span>
      </button>

      {open && (
        <div
          className="fixed inset-0 z-[200] flex flex-col justify-end"
          style={{ background: "rgba(0,0,0,0.55)", backdropFilter: "blur(2px)" }}
        >
          <div className="absolute inset-0" onClick={() => setOpen(false)} />
          <div
            className="relative bg-white rounded-t-3xl w-full max-h-[92vh] overflow-y-auto"
            style={{ animation: "slideUp 0.28s cubic-bezier(0.32,0.72,0,1)" }}
          >
            <div className="flex justify-center pt-3 pb-1">
              <div className="w-10 h-1 rounded-full bg-gray-200" />
            </div>
            <div className="flex items-center justify-between px-5 py-3 border-b border-gray-100">
              <div>
                <h2 className="text-lg font-bold text-gray-900">Buat Lowongan Baru</h2>
                <p className="text-xs text-gray-500 mt-0.5">Tampil di peta · Anti-penipuan aktif</p>
              </div>
              <button data-testid="button-close-modal" onClick={() => setOpen(false)}
                className="w-9 h-9 flex items-center justify-center rounded-full bg-gray-100">
                <X className="w-4 h-4 text-gray-600" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="px-5 py-5 space-y-5">

              {/* ── Tipe Bisnis ── */}
              <div className="space-y-2">
                <label className="text-sm font-semibold text-gray-800 flex items-center gap-1.5">
                  <Building2 className="w-3.5 h-3.5 text-primary" /> Tipe Bisnis <span className="text-red-500">*</span>
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {([
                    { val: "perusahaan" as TipeAkun, label: "Perusahaan Langsung", sub: "Kafe, Resto, Hotel, Kantor" },
                    { val: "agensi" as TipeAkun, label: "Agensi / EO / Outsourcing", sub: "Penyedia Tenaga Kerja Massal" },
                  ] as const).map((opt) => (
                    <button
                      key={opt.val} type="button"
                      data-testid={`button-tipe-${opt.val}`}
                      onClick={() => setTipeAkun(opt.val)}
                      className={`p-3 rounded-xl text-left border transition-all ${
                        tipeAkun === opt.val
                          ? "bg-primary text-white border-primary shadow-md"
                          : "bg-white text-gray-700 border-gray-200 hover:border-primary/40"
                      }`}
                    >
                      <p className={`text-xs font-bold leading-tight ${tipeAkun === opt.val ? "text-white" : ""}`}>{opt.label}</p>
                      <p className={`text-[10px] mt-0.5 leading-tight ${tipeAkun === opt.val ? "text-white/70" : "text-gray-400"}`}>{opt.sub}</p>
                    </button>
                  ))}
                </div>

                {/* Agency bulk info banner */}
                {isAgency && (
                  <div className="flex items-start gap-2 rounded-xl px-3 py-2.5 bg-emerald-50 border border-emerald-200">
                    <Users className="w-4 h-4 shrink-0 mt-0.5 text-emerald-600" />
                    <div>
                      <p className="text-xs font-bold text-emerald-700">Perekrutan Massal Agensi</p>
                      <p className="text-[11px] text-emerald-600 mt-0.5">
                        Setiap pekerja menerima <strong>100% upah</strong> — biaya platform {(DEFAULT_FEE_RATE * 100).toFixed(0)}% ditanggung penuh oleh perusahaan.
                      </p>
                    </div>
                  </div>
                )}
              </div>

              {/* ── Agency kuota massal ── */}
              {isAgency && (
                <div className="space-y-1.5">
                  <label className="text-sm font-semibold text-gray-800 flex items-center gap-1.5">
                    <Users className="w-3.5 h-3.5 text-primary" />
                    Kuota Tenaga Kerja Massal <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <input
                      data-testid="input-kuota-massal"
                      type="number" min="1" max="999"
                      value={kuotaMassal}
                      onChange={(e) => setKuotaMassal(e.target.value)}
                      className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-900 focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all"
                    />
                    <span className="absolute right-4 top-1/2 -translate-y-1/2 text-sm text-gray-400">orang</span>
                  </div>
                  <p className="text-[10px] text-gray-400">
                    Maksimal 999 tenaga kerja per lowongan · Pin di peta akan ditandai <strong>[AGENCY JOB]</strong>
                  </p>
                </div>
              )}

              {/* ── Nama Perusahaan / Agensi ── */}
              <div className="space-y-1.5">
                <label className="text-sm font-semibold text-gray-800">
                  {isAgency ? "Nama Agensi / EO" : "Nama Perusahaan"}
                </label>
                <input
                  data-testid="input-nama-perusahaan" type="text"
                  value={namaPerusahaan} onChange={(e) => setNamaPerusahaan(e.target.value)}
                  placeholder={isAgency ? "cth: PT Event Pro Indonesia, EO Spekta" : "cth: PT Kopi Kenangan, CV Event Pro"}
                  className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all"
                />
              </div>

              {/* ── NIB ── */}
              <div className="space-y-1.5">
                <label className="text-sm font-semibold text-gray-800 flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-primary" />
                  NIB / KTP Perusahaan
                  <span className="text-[10px] font-normal text-gray-500">(opsional, 13 digit)</span>
                </label>
                <input
                  data-testid="input-nib" type="text" inputMode="numeric"
                  value={nibPerusahaan} onChange={handleNibChange}
                  maxLength={13} placeholder="1234567890123"
                  className={`w-full border rounded-xl px-4 py-3 text-sm text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 transition-all ${nibError ? "border-red-300 focus:ring-red-200" : "border-gray-200 focus:ring-primary/30 focus:border-primary"}`}
                />
                {nibError && <p className="text-[11px] text-red-500 flex items-center gap-1"><AlertTriangle className="w-3 h-3" />{nibError}</p>}
                {nibPerusahaan.length === 13 && <p className="text-[11px] text-primary flex items-center gap-1"><ShieldCheck className="w-3 h-3" /> NIB terverifikasi</p>}
              </div>

              {/* ── Posisi ── */}
              <div className="space-y-1.5">
                <label className="text-sm font-semibold text-gray-800">Nama Posisi / Pekerjaan <span className="text-red-500">*</span></label>
                <input
                  data-testid="input-posisi" type="text" value={posisi}
                  onChange={(e) => setPosisi(e.target.value)}
                  placeholder="cth: Asisten Fotografer, Penjaga Booth"
                  className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all"
                  required
                />
              </div>

              {/* ── Deskripsi + Fraud ── */}
              <div className="space-y-1.5">
                <label className="text-sm font-semibold text-gray-800">Deskripsi & Tugas <span className="text-red-500">*</span></label>
                <textarea
                  data-testid="input-deskripsi" value={deskripsi}
                  onChange={handleDeskripsiChange}
                  placeholder="Jelaskan tugas, instruksi kerja, dan ekspektasi Anda..."
                  rows={4}
                  className={`w-full border rounded-xl px-4 py-3 text-sm text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 transition-all resize-none ${fraudWarning ? "border-red-300 focus:ring-red-200 bg-red-50" : "border-gray-200 focus:ring-primary/30 focus:border-primary"}`}
                  required
                />
                {fraudWarning ? (
                  <div className="flex items-start gap-2 bg-red-50 border border-red-200 rounded-xl px-3 py-2.5">
                    <AlertTriangle className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                    <p className="text-[11px] text-red-600 leading-relaxed">
                      <strong>⚠️ Kata Kunci Penipuan:</strong> "{fraudWarning}" terdeteksi. Hapus untuk melanjutkan.
                    </p>
                  </div>
                ) : (
                  <p className="text-[10px] text-gray-400 flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3 text-primary" /> Sensor anti-penipuan aktif
                  </p>
                )}
              </div>

              {/* ── Durasi Kontrak ── */}
              <div className="space-y-1.5">
                <label className="text-sm font-semibold text-gray-800">Durasi Kontrak Kerja</label>
                <select
                  data-testid="select-durasi-kontrak" value={durasiKontrak}
                  onChange={(e) => setDurasiKontrak(e.target.value as DurasiKontrak)}
                  className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-900 bg-white focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all"
                >
                  {durasiKontrakOptions.map((opt) => (
                    <option key={opt.value} value={opt.value}>
                      {opt.label}
                    </option>
                  ))}
                </select>
                <p className="text-[11px] text-gray-500">
                  Biaya platform:{" "}
                  <span className="font-bold text-primary">
                    {(DEFAULT_FEE_RATE * 100).toFixed(0)}% (beban perusahaan, pekerja terima 100%)
                  </span>
                </p>
              </div>

              {/* ── Sistem Bayaran ── */}
              <div className="space-y-1.5">
                <label className="text-sm font-semibold text-gray-800">Sistem Bayaran</label>
                <div className="flex gap-2">
                  {(["per_shift", "per_hari", "per_projek", "per_bulan"] as PaymentType[]).map((type) => (
                    <button key={type} type="button" data-testid={`button-payment-${type}`}
                      onClick={() => setPembayaran(type)}
                      className={`flex-1 py-2.5 px-2 rounded-xl text-xs font-semibold border transition-all ${pembayaran === type ? "bg-primary text-white border-primary" : "bg-white text-gray-600 border-gray-200"}`}>
                      {paymentLabels[type]}
                    </button>
                  ))}
                </div>
              </div>

              {/* ── Nominal ── */}
              <div className="space-y-1.5">
                <label className="text-sm font-semibold text-gray-800">Nominal Bayaran <span className="text-red-500">*</span></label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-sm font-medium text-gray-500">Rp</span>
                  <input
                    data-testid="input-nominal" type="text" inputMode="numeric"
                    value={nominal} onChange={handleNominalChange} placeholder="0"
                    className="w-full border border-gray-200 rounded-xl pl-10 pr-4 py-3 text-sm text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all"
                    required
                  />
                </div>

                {nominalNum > 0 && (
                  <div className="mt-2 rounded-xl border border-primary/15 bg-primary/5 px-4 py-3 space-y-2" data-testid="commission-preview">
                    <div className="flex justify-between text-xs">
                      <span className="text-gray-600">Upah ke pekerja (100%)</span>
                      <span className="font-bold text-primary">{formatRupiah(total)}</span>
                    </div>
                    <div className="flex justify-between text-xs border-t border-primary/10 pt-2">
                      <span className="text-gray-600">Biaya platform ({(DEFAULT_FEE_RATE * 100).toFixed(0)}%, beban perusahaan)</span>
                      <span className="font-semibold text-gray-700">{formatRupiah(calcEmployerFee(total))}</span>
                    </div>
                    <div className="flex justify-between text-xs border-t border-primary/10 pt-2">
                      <span className="font-semibold text-gray-800">Total Anda setor ke escrow</span>
                      <span className="font-bold text-gray-900">{formatRupiah(calcEmployerDeposit(total))}</span>
                    </div>
                    {isAgency && effectiveKuota > 1 && (
                      <div className="flex justify-between text-xs border-t border-primary/10 pt-2">
                        <span className="font-semibold text-gray-800">Total ({effectiveKuota} orang)</span>
                        <span className="font-bold text-violet-700">{formatRupiah(calcEmployerDeposit(total) * effectiveKuota)}</span>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* ── Dresscode ── */}
              <div className="space-y-1.5">
                <label className="text-sm font-semibold text-gray-800">Persyaratan Pakaian <span className="text-red-500">*</span></label>
                <input
                  data-testid="input-dresscode" type="text" value={dresscode}
                  onChange={(e) => setDresscode(e.target.value)}
                  placeholder="cth: Baju bebas rapi, bawa laptop sendiri"
                  className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all"
                  required
                />
              </div>

              {/* ── Kuota (non-agency only) ── */}
              {!isAgency && (
                <div className="space-y-1.5">
                  <label className="text-sm font-semibold text-gray-800">Kuota Pekerja</label>
                  <div className="flex items-center gap-3">
                    <button type="button" onClick={() => setKuota((k) => String(Math.max(1, parseInt(k) - 1)))}
                      className="w-10 h-10 rounded-full border border-gray-200 flex items-center justify-center text-lg font-bold text-gray-600 hover:bg-gray-50">−</button>
                    <span className="text-xl font-bold text-gray-900 w-8 text-center">{kuota}</span>
                    <button type="button" onClick={() => setKuota((k) => String(parseInt(k) + 1))}
                      className="w-10 h-10 rounded-full border border-gray-200 flex items-center justify-center text-lg font-bold text-gray-600 hover:bg-gray-50">+</button>
                    <span className="text-sm text-gray-500 ml-1">orang dibutuhkan</span>
                  </div>
                </div>
              )}

              {/* ── Jumlah Hari ── */}
              {pembayaran !== "per_projek" && (
                <div className="space-y-1.5">
                  <label className="text-sm font-semibold text-gray-800 flex items-center gap-1.5">
                    <Lock className="w-3.5 h-3.5 text-blue-600" />
                    Estimasi Jumlah Hari Kerja
                    <span className="text-[10px] font-normal text-gray-500">(untuk kalkulator escrow)</span>
                  </label>
                  <div className="flex items-center gap-3">
                    <button type="button" onClick={() => setJumlahHari(d => Math.max(1, d - 1))}
                      className="w-10 h-10 rounded-full border border-gray-200 flex items-center justify-center text-lg font-bold text-gray-600 hover:bg-gray-50">−</button>
                    <span className="text-xl font-bold text-gray-900 w-8 text-center">{jumlahHari}</span>
                    <button type="button" onClick={() => setJumlahHari(d => d + 1)}
                      className="w-10 h-10 rounded-full border border-gray-200 flex items-center justify-center text-lg font-bold text-gray-600 hover:bg-gray-50">+</button>
                    <span className="text-sm text-gray-500 ml-1">hari</span>
                  </div>
                </div>
              )}

              <div className="pt-2 pb-6">
                <button
                  data-testid="button-submit-job" type="submit"
                  disabled={blocked || (nibPerusahaan.length > 0 && nibPerusahaan.length < 13)}
                  className={`w-full font-bold py-3.5 rounded-xl text-base transition-all ${
                    blocked || (nibPerusahaan.length > 0 && nibPerusahaan.length < 13)
                      ? "bg-gray-200 text-gray-400 cursor-not-allowed"
                      : "bg-primary text-white hover:bg-primary/90 active:scale-[0.98] shadow-lg"
                  }`}
                  style={!blocked ? { boxShadow: "0 4px 16px rgba(6,95,70,0.35)" } : {}}
                >
                  {blocked ? "⚠️ Hapus Kata Kunci Penipuan Dulu" : "Lanjut → Konfirmasi Escrow"}
                </button>
              </div>
            </form>

            {/* ── ESCROW CONFIRMATION OVERLAY ─────────── */}
            {showEscrowConfirm && nominalNum > 0 && (
              <div className="absolute inset-0 bg-white rounded-t-3xl z-10 flex flex-col overflow-y-auto">
                <div className="flex items-center gap-3 px-5 py-4 border-b border-gray-100">
                  <button onClick={() => setShowEscrowConfirm(false)}
                    className="w-9 h-9 flex items-center justify-center rounded-full bg-gray-100">
                    <ChevronLeft className="w-4 h-4 text-gray-600" />
                  </button>
                  <div>
                    <h3 className="text-base font-bold text-gray-900">Konfirmasi Escrow</h3>
                    <p className="text-xs text-gray-500">Dana dikunci sebelum lowongan aktif</p>
                  </div>
                </div>

                <div className="px-5 py-5 space-y-5 pb-8">
                  {/* Status badge */}
                  <div className="flex items-center justify-center gap-2 bg-blue-50 border border-blue-200 rounded-2xl px-4 py-3">
                    <Lock className="w-4 h-4 text-blue-600" />
                    <span className="text-sm font-bold text-blue-800">[DANA AKAN DIKUNCI DI ESCROW]</span>
                  </div>

                  {/* Cost breakdown */}
                  <div className="bg-gray-50 rounded-2xl border border-gray-100 overflow-hidden">
                    <div className="px-4 py-3 border-b border-gray-100 bg-white">
                      <p className="text-sm font-bold text-gray-900">📊 Kalkulator Biaya Otomatis</p>
                    </div>
                    <div className="px-4 py-3 space-y-2.5">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Upah per pekerja</span>
                        <span className="font-semibold text-gray-900">Rp {nominalNum.toLocaleString("id-ID")} / {paymentLabels[pembayaran]}</span>
                      </div>
                      {pembayaran !== "per_projek" && (
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-600">Jumlah hari kerja</span>
                          <span className="font-semibold text-gray-900">{jumlahHari} hari</span>
                        </div>
                      )}
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Jumlah pekerja</span>
                        <span className="font-semibold text-gray-900">{effectiveKuota} orang</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Subtotal upah pekerja</span>
                        <span className="font-semibold text-gray-900">Rp {escrowGross.toLocaleString("id-ID")}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Biaya platform ({(DEFAULT_FEE_RATE * 100).toFixed(0)}%, beban perusahaan)</span>
                        <span className="font-semibold text-gray-700">Rp {escrowSplit.platformCut.toLocaleString("id-ID")}</span>
                      </div>
                      <div className="flex justify-between text-sm font-bold border-t border-gray-200 pt-2.5">
                        <span className="text-gray-900">Total Dana Dikunci ke Escrow</span>
                        <span className="text-blue-700">Rp {escrowDeposit.toLocaleString("id-ID")}</span>
                      </div>
                    </div>
                  </div>

                  {/* Payout breakdown */}
                  <div className="bg-gray-50 rounded-2xl border border-gray-100 overflow-hidden">
                    <div className="px-4 py-3 border-b border-gray-100 bg-white">
                      <p className="text-sm font-bold text-gray-900">💸 Rincian Pelepasan Dana (saat Selesai)</p>
                    </div>
                    <div className="px-4 py-3 space-y-2.5">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Biaya Platform Rekhastha ({(DEFAULT_FEE_RATE * 100).toFixed(0)}% Beban Perusahaan)</span>
                        <span className="font-semibold text-gray-700">Rp {escrowSplit.platformCut.toLocaleString("id-ID")}</span>
                      </div>
                      <div className="flex justify-between text-sm font-bold border-t border-gray-200 pt-2.5">
                        <span className="text-primary">Upah Bersih ke Pekerja (100%)</span>
                        <span className="text-primary">Rp {escrowSplit.workerNet.toLocaleString("id-ID")}</span>
                      </div>
                      <p className="text-[10px] text-emerald-700/80 leading-relaxed">
                        🟢 Pekerja menerima 100% upah utuh — biaya platform ditanggung penuh oleh perusahaan.
                      </p>
                      <p className="text-[10px] text-gray-400 leading-relaxed border-t border-gray-200 pt-2.5">
                        Segala kewajiban perpajakan menjadi tanggung jawab mandiri masing-masing pihak sesuai hukum yang berlaku.
                      </p>
                    </div>
                  </div>

                  <p className="text-[11px] text-gray-400 text-center leading-relaxed">
                    Lowongan hanya akan aktif di peta setelah dana dikunci. Dana dapat dicairkan kembali jika tidak ada pekerja yang diterima dalam 7 hari.
                  </p>

                  <button
                    onClick={handleEscrowConfirm}
                    className="w-full flex items-center justify-center gap-2 bg-blue-700 hover:bg-blue-800 text-white font-bold py-4 rounded-2xl text-sm transition-all active:scale-[0.98]"
                    style={{ boxShadow: "0 4px 20px rgba(29,78,216,0.4)" }}
                  >
                    <Lock className="w-5 h-5" />
                    Simulasi Transfer ke Escrow Rekhastha
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      <style>{`@keyframes slideUp { from{transform:translateY(100%);opacity:0.6} to{transform:translateY(0);opacity:1} }`}</style>
    </>
  );
}
